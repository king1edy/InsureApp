using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVCGrid.Web;
using MVCGrid.Models;
using System.Web.Mvc;
using InsureApp.Data;
//using InsureApp.Core;
using InsureApp.Service.Abstract;
using InsureApp.Service.Concrete;

namespace InsureApp.Web.App_Start
{
    public class MVCGridConfig
    {
        private string CustomerType;
 
        public void RegisterGrids()
        {
            // add your Grid definitions here, using the MVCGridDefinitionTable.Add method

            MVCGridDefinitionTable.Add("PrivateCustomer", new MVCGridBuilder<Customer>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Customer Id")
                    .WithSorting(true)
                    .WithValueExpression(i => i.CustId.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("FirstName")
                    .WithSorting(true)
                    .WithValueExpression(i => i.FirstName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("LastName")
                    .WithSorting(true)
                    .WithValueExpression(i => i.LastName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Gender")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Gender); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Email")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Email); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                         .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                         .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/PrivateCustomer/Edit' data-id='{Model.Id}' data-urlData='/PrivateCustomer/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/AddPic/{Model.Id}'><span class='glyphicon glyphicon-user'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                         .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<ICustomerService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, "Private", options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Customer>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            //A New Grid definition for Corporate-Customer
            MVCGridDefinitionTable.Add("CorporateCustomer", new MVCGridBuilder<Customer>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Customer ID")
                    .WithSorting(true)
                    .WithValueExpression(i => i.CustId.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.CompanyName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Registration Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.RegistrationNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Nature Of Business")
                    .WithSorting(true)
                    .WithValueExpression(i => i.NatureOfBusiness); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Year Incorporated")
                    .WithSorting(true)
                    .WithValueExpression(i => i.YearIncorporated); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("State Province")
                    .WithSorting(true)
                    .WithValueExpression(i => i.StateProvince); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                         .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                         .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/CorporateCustomer/Edit' data-id='{Model.Id}' data-urlData='/CorporateCustomer/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/AddPic/{Model.Id}'><span class='glyphicon glyphicon-user'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                         .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<ICustomerService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, "Corporate", options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Customer>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);

            // add your Grid definitions here, using the MVCGridDefinitionTable.Add method

            MVCGridDefinitionTable.Add("AllCustomerGrid", new MVCGridBuilder<Customer>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search", "CustomerType")
            //.WithPageParameterNames("CustomerType")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Customer Id")
                    .WithSorting(true)
                    .WithValueExpression(i => i.CustId.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("FirstName")
                    .WithSorting(true)
                    //.WithVisibility(true)
                    .WithAllowChangeVisibility(true)
                    .WithValueExpression(i => i.FirstName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("LastName")
                    .WithSorting(true)
                    //.WithVisibility(true)
                    .WithAllowChangeVisibility(true)
                    .WithValueExpression(i => i.LastName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Gender")
                    .WithSorting(true)
                    .WithVisibility(true)
                    .WithAllowChangeVisibility(true)
                    .WithValueExpression(i => i.Gender); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Email")
                    .WithSorting(true)
                    //.WithVisibility(true)
                    .WithValueExpression(i => i.Email); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Company Name")
                    .WithSorting(true)
                    .WithAllowChangeVisibility(false)
                    .WithVisibility(false)
                    .WithValueExpression(i => i.CompanyName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Year Incorporated")
                    .WithSorting(true)
                    .WithVisibility(false)
                    .WithAllowChangeVisibility(false)
                    .WithValueExpression(i => i.YearIncorporated); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Nature Of Business")
                    .WithSorting(true)
                    .WithAllowChangeVisibility(false)
                    .WithVisibility(false)
                    .WithValueExpression(i => i.NatureOfBusiness); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Registration Number")
                    .WithSorting(true)
                    .WithAllowChangeVisibility(false)
                    .WithVisibility(false)
                    .WithValueExpression(i => i.RegistrationNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "allLastColumn" : "allLastColumn")
                         .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                         .WithValueTemplate("<a href='javascript:void(0);' data-url='/CustomerSearch/Confirm' data-customer-id='{Model.Id}' data-cust-id='{Model.CustId}' onclick='loadConfirmation(this)' ><span class='glyphicon glyphicon-list-alt'></span></a>", false)
                         .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        List<ColumnVisibility> columns = options.ColumnVisibility;
        this.CustomerType = "";
        foreach (ColumnVisibility column in columns)
        {
            if (column.ColumnName == "Company Name" && column.Visible)
            {
                CustomerType = "Corporate";
                break;
            }
        }
        
        int totalRecords;
        this.CustomerType = this.CustomerType == "Corporate" ? this.CustomerType : "Private"; //options.AdditionalQueryOptions["CustomerType"] == null ? "Private" : options.AdditionalQueryOptions["CustomerType"];
        var repo = DependencyResolver.Current.GetService<ICustomerService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, CustomerType, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Customer>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);

            //A New Grid definition for Agent Grid
            MVCGridDefinitionTable.Add("Agent", new MVCGridBuilder<Agent>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Name); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Registration Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.RegistrationNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Agent Class")
                    .WithSorting(true)
                    .WithValueExpression(i => i.AgentClass); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Agent Type")
                    .WithSorting(true)
                    .WithValueExpression(i => i.AgentType); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("State Province")
                    .WithSorting(true)
                    .WithValueExpression(i => i.State); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Phone")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Phone); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Email")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Email); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                         .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                         .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/Agent/Edit' data-id='{Model.Id}' data-urlData='/Agent/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                         .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IAgentService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Agent>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);


            //A New Grid definition for Agent Grid
            MVCGridDefinitionTable.Add("AgentContact", new MVCGridBuilder<AgentContact>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Agent Id")
                    .WithSorting(true)
                    .WithValueExpression(i => i.AgentId.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("First Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.FirstName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Last Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.LastName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Email")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Email); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Phone")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Phone); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Designation")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Designation); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                         .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                         .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/AgentContact/Edit' data-urlData='/AgentContact/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                         + "<a href='/Customer/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                         .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IAgentContactService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<AgentContact>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);

            // A New Grid definiton for Aviation

            MVCGridDefinitionTable.Add("Aviation", new MVCGridBuilder<Aviation>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Policy Number")
                   .WithSorting(true)
                   .WithValueExpression(i => i.PolicyNumber.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Insured Interest")
                    .WithSorting(true)
                    .WithValueExpression(i => i.InsuredInterest.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("VoyageFrom")
                    .WithSorting(true)
                    .WithValueExpression(i => i.VoyageFrom); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Voyage To")
                    .WithSorting(true)
                    .WithValueExpression(i => i.VoyageTo); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Clauses")
                   .WithSorting(true)
                   .WithValueExpression(i => i.Clauses); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Exclusions")
                   .WithSorting(true)
                   .WithValueExpression(i => i.Exclusions); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Year Of Manufacture")
                    .WithSorting(true)
                    .WithValueExpression(i => i.YearOfManufacture); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Place Of Manufacture")
                    .WithSorting(true)
                    .WithValueExpression(i => i.PlaceOfManufacture); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/Aviation/Edit' data-id='{Model.Id}' data-customer-id='{Model.CustomerId}' data-urlData='/Aviation/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/Aviation/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/Aviation/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IAviationService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Aviation>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for Bond

            MVCGridDefinitionTable.Add("Bond", new MVCGridBuilder<Bond>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Policy Number")
                   .WithSorting(true)
                   .WithValueExpression(i => i.PolicyNumber.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Contract")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Contract.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Effective Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.EffectiveDate.ToString("dd/MM/yyyy")); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Situation Of Risk")
                    .WithSorting(true)
                    .WithValueExpression(i => i.SituationOfRisk); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Business Type")
                   .WithSorting(true)
                   .WithValueExpression(i => i.BusinessType); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Business Occupation")
                   .WithSorting(true)
                   .WithValueExpression(i => i.BusinessOccupation); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Item Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.ItemNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Employers Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.EmployeeName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a href='/Bond/Edit/{Model.Id}' data-cust-id='{Model.CustomerId}'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/Bond/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/Bond/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IBondService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Bond>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for MarineCargo

            MVCGridDefinitionTable.Add("Marine", new MVCGridBuilder<Marine>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Form M Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.FormMNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Voyage From")
                    .WithSorting(true)
                    .WithValueExpression(i => i.VoyageFrom); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Voyage To")
                   .WithSorting(true)
                   .WithValueExpression(i => i.VoyageTo); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Insured Interest")
                   .WithSorting(true)
                   .WithValueExpression(i => i.InsuredInterest.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Condition")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Conditions.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Package Type")
                    .WithSorting(true)
                    .WithValueExpression(i => i.PackageType); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/Marine/Edit' data-id='{Model.Id}' data-cust-id='{Model.CustomerId}' data-urlData='/Marine/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/Marine/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/Marine/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IMarineService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Marine>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for ContactPerson

            MVCGridDefinitionTable.Add("ContactPerson", new MVCGridBuilder<ContactPerson>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("First Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.FirstName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Last Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.LastName); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Email")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Email); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Phone")
                   .WithSorting(true)
                   .WithValueExpression(i => i.Phone); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Designation")
                   .WithSorting(true)
                   .WithValueExpression(i => i.Designation); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Is BoardMember")
                    .WithSorting(true)
                    .WithValueExpression(i => i.IsBoardMember); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a href='/ContactPerson/Edit/{Model.Id}'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/ContactPerson/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/ContactPerson/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IContactPersonService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<ContactPerson>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for RiskProfile

            MVCGridDefinitionTable.Add("RiskProfile", new MVCGridBuilder<RiskProfile>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Name); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Policy Type")
                    .WithSorting(true)
                    .WithValueExpression(i => i.PolicyType); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Description")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Description); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a href='/RiskProfile/Edit/{Model.Id}'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/RiskProfile/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/RiskProfile/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IRiskProfileService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<RiskProfile>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for TravelAndHealth

            MVCGridDefinitionTable.Add("TravelAndHealth", new MVCGridBuilder<TravelAndHealth>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Policy Number")
                   .WithSorting(true)
                   .WithValueExpression(i => i.PolicyNumber.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Item Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.ItemNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Next Of Kin")
                    .WithSorting(true)
                    .WithValueExpression(i => i.NextOfKin); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Next Of Kin Phone")
                    .WithSorting(true)
                    .WithValueExpression(i => i.NextOfKinTelephoneNo); // use the value Expression to return the cell text for this column
                cols.Add().WithColumnName("Passport Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.PassportNumber); // use the value Expression to return the cell text for this column
                cols.Add().WithColumnName("Risk Profile")
                    .WithSorting(true)
                    .WithValueExpression(i => i.RiskProfile); // use the value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/TravelAndHealth/Edit'  data-id='{Model.Id}' data-cust-id='{Model.CustomerId}' data-urlData='/TravelAndHealth/EditData/{Model.Id}' onClick='return editRow(this)''><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/TravelAndHealth/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/TravelAndHealth/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<ITravelAndHealthService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<TravelAndHealth>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for OrgStructureName

            MVCGridDefinitionTable.Add("OrgStructureName", new MVCGridBuilder<OrgStructureName>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Asc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Name); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Parent")
                    .WithSorting(true)
                    .WithValueExpression(i => i.OrgStructureName2 != null ? i.OrgStructureName2.Name : ""); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("details", new { id = i.Id }))
                    .WithValueTemplate("<a href='/OrgStructureValue/Index' data-orgstructurenameId='{Model.Id}' data-parentId='{Model.ParentId}' onClick='return loadStructureValue(this)' id='AddStructureValue'><span class='glyphicon glyphicon-plus'></span></a>" + "&nbsp;"
                    + "<a id='edit' href='#' data-urlStructure='/OrgStructureName/Edit' data-urlData='/OrgStructureName/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/OrgStructureName/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IOrgStructureNameService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<OrgStructureName>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for OrgStructureValue

            MVCGridDefinitionTable.Add("OrgStructureValue", new MVCGridBuilder<OrgStructureValue>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithPageParameterNames("OrgStructureNameId")
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Setup Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.OrgStructureName != null ? i.OrgStructureName.Name : ""); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Name")
                    .WithSorting(true)
                    .WithValueExpression(i => i.Name); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Parent")
                    .WithSorting(true)
                    .WithValueExpression(i => i.OrgStructureValue2 != null ? i.OrgStructureValue2.Name : ""); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a id='edit' href='#' data-parentId='{Model.OrgStructureNameId}' data-urlStructure='/OrgStructureValue/Edit' data-urlData='/OrgStructureValue/EditData/{Model.Id}' onClick='return editRow(this)'></span></a>" + "&nbsp;"
                    + "<a href='/OrgStructureValue/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/OrgStructureValue/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        int OrgStructureNameId =  options.GetPageParameterString("OrgStructureNameId") != null ?  Convert.ToInt32( options.GetPageParameterString("OrgStructureNameId")) : 0;
        var repo = DependencyResolver.Current.GetService<IOrgStructureValueService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, OrgStructureNameId, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<OrgStructureValue>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            MVCGridDefinitionTable.Add("MiscSetUpName", new MVCGridBuilder<MiscSetUpName>()
          .WithAuthorizationType(AuthorizationType.AllowAnonymous)
          .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
          .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
          .WithAdditionalQueryOptionNames("search")
          .AddColumns(cols =>
          {
              // Add your columns here
              cols.Add().WithColumnName("Name")
                  .WithSorting(true)
                  .WithValueExpression(i => i.Name); // use the Value Expression to return the cell text for this column
              cols.Add().WithColumnName("Parent")
                  .WithSorting(true)
                  .WithValueExpression(i => i.MiscSetUpName2 == null ? "" : i.MiscSetUpName2.Name); // use the Value Expression to return the cell text for this column

              cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                   .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                   .WithValueTemplate("<a id='details' href='/MiscSetUpValue/Index' data-setupnameid='{Model.Id}' data-parentId='{Model.ParentId}' onClick='return loadSetUpValue(this)'><span class='glyphicon glyphicon-plus'></span></a>" + "&nbsp;"
                   + "<a id='edit' href='#' data-urlStructure='/MiscSetUpName/Edit' data-urlData='/MiscSetUpName/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                   + "<a id = 'delete' href='/MiscSetUpName/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                   .WithPlainTextValueExpression(p => p.Id.ToString()); ;
          })
  .WithRetrieveDataMethod((context) =>
  {
      var options = context.QueryOptions;
      int totalRecords;
      var repo = DependencyResolver.Current.GetService<IMiscSetUpNameService>();
      string globalSearch = options.GetAdditionalQueryOptionString("search");
      string sortColumn = options.GetSortColumnData<string>();
      var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
      sortColumn, options.SortDirection == SortDirection.Dsc);
      return new QueryResult<MiscSetUpName>()
      {
          Items = items,
          TotalRecords = totalRecords
      };
  })
);
            MVCGridDefinitionTable.Add("MiscSetUpValue", new MVCGridBuilder<MiscSetUpValue>()
           .WithAuthorizationType(AuthorizationType.AllowAnonymous)
           .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
           .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
           .WithAdditionalQueryOptionNames("search")
           .WithPageParameterNames("SetUpNameId")
           .AddColumns(cols =>
           {
               // Add your columns here
               cols.Add().WithColumnName("Setup Name")
                  .WithSorting(true)
                  .WithValueExpression(i => i.MiscSetUpName.Name); // use the Value Expression to return the cell text for this column
               cols.Add().WithColumnName("Name")
                   .WithSorting(true)
                   .WithValueExpression(i => i.Name); // use the Value Expression to return the cell text for this column
               cols.Add().WithColumnName("Parent")
                   .WithSorting(true)
                   .WithValueExpression(i => i.MiscSetUpValue2 != null ? i.MiscSetUpValue2.Name : ""); // use the Value Expression to return the cell text for this column
               cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/MiscSetUpValue/Edit' data-urlData='/MiscSetUpValue/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/MiscSetUpValue/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
           })
   .WithRetrieveDataMethod((context) =>
   {
       var options = context.QueryOptions;
       int totalRecords;
       int SetUpNameId = options.GetPageParameterString("SetUpNameId") != null ? Convert.ToInt32(options.GetPageParameterString("SetUpNameId")) : 0;
       var repo = DependencyResolver.Current.GetService<IMiscSetUpValueService>();
       string globalSearch = options.GetAdditionalQueryOptionString("search");
       string sortColumn = options.GetSortColumnData<string>();
       var items = repo.GetData(out totalRecords, globalSearch, SetUpNameId, options.GetLimitOffset(), options.GetLimitRowcount(),
       sortColumn, options.SortDirection == SortDirection.Dsc);
       return new QueryResult<MiscSetUpValue>()
       {
           Items = items,
           TotalRecords = totalRecords
       };
   })
 );


            // A New Grid definiton for GeneralAccident

            MVCGridDefinitionTable.Add("GeneralAccident", new MVCGridBuilder<GeneralAccident>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Policy Number")
                   .WithSorting(true)
                   .WithValueExpression(i => i.PolicyNumber.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Category Of Employee")
                    .WithSorting(true)
                    .WithValueExpression(i => i.CategoriesOfEmployee); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Effective Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.EffectiveDate.ToString("dd/MM/yyyy"));  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Risk Profile")
                    .WithSorting(true)
                    .WithValueExpression(i => i.RiskProfile);  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Last Claim Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.LastClaimDate.ToString("dd/MM/yyyy"));  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Business Type")
                    .WithSorting(true)
                    .WithValueExpression(i => i.BusinessType);  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a href='/GeneralAccident/Edit/{Model.Id}'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/GeneralAccident/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/GeneralAccident/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IGeneralAccidentService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<GeneralAccident>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for Fire

            MVCGridDefinitionTable.Add("Fire", new MVCGridBuilder<Fire>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Policy Number")
                   .WithSorting(true)
                   .WithValueExpression(i => i.PolicyNumber.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Item Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.ItemNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Effective Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.EffectiveDate.ToString("dd/MM/yyyy"));  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Risk Profile")
                    .WithSorting(true)
                    .WithValueExpression(i => i.RiskProfile);  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Last Claim Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.LastClaimDate.ToString("dd/MM/yyyy"));  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Business Type")
                    .WithSorting(true)
                    .WithValueExpression(i => i.BusinessType);  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/Fire/Edit' data-id='{Model.Id}' data-customer-id='{Model.CustomerId}' data-urlData='/Fire/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/Fire/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/Fire/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IFireService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Fire>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
);
            // A New Grid definiton for Fire

            MVCGridDefinitionTable.Add("Motor", new MVCGridBuilder<Motor>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Vehicle Make")
                   .WithSorting(true)
                   .WithValueExpression(i => i.VehicleMake); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Vehicle Model")
                    .WithSorting(true)
                    .WithValueExpression(i => i.VehicleModel); // use the value Expression to return the call text for this column
                cols.Add().WithColumnName("Item Number")
                    .WithSorting(true)
                    .WithValueExpression(i => i.ItemNumber); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Effective Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.EffectiveDate.ToString("dd/MM/yyyy"));  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Risk Profile")
                    .WithSorting(true)
                    .WithValueExpression(i => i.RiskProfile);  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Last Claim Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.LastClaimDate.ToString());  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Vehicle Registration No")
                    .WithSorting(true)
                    .WithValueExpression(i => i.VehicleRegistrationNo);  // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                    .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                    .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/Motor/Edit' data-id='{Model.Id}' data-customer-id='{Model.CustomerId}' data-urlData='/Motor/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                    + "<a href='/Motor/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                    + "<a href='/Motor/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                    .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IMotorService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<Motor>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
    );
            MVCGridDefinitionTable.Add("GasAndOil", new MVCGridBuilder<GasAndOil>()
            .WithAuthorizationType(AuthorizationType.AllowAnonymous)
            .WithSorting(sorting: true, defaultSortColumn: "Id", defaultSortDirection: SortDirection.Dsc)
            .WithPaging(paging: true, itemsPerPage: 10, allowChangePageSize: true, maxItemsPerPage: 100)
            .WithAdditionalQueryOptionNames("search")
            .AddColumns(cols =>
            {
                // Add your columns here
                cols.Add().WithColumnName("Inspection Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.InspectionDate.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Status Of Well")
                    .WithSorting(true)
                    .WithValueExpression(i => i.StatusOfWell); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Premium Or Rate")
                    .WithSorting(true)
                    .WithValueExpression(i => i.PremiumOrRate.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Prorata Days")
                    .WithSorting(true)
                    .WithValueExpression(i => i.ProrataDays.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Last Claim Date")
                    .WithSorting(true)
                    .WithValueExpression(i => i.LastClaimDate.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Excess Deductibles")
                    .WithSorting(true)
                    .WithValueExpression(i => i.ExcessDeductibles.ToString()); // use the Value Expression to return the cell text for this column
                cols.Add().WithColumnName("Action").WithCellCssClassExpression(p => p.Id != 0 ? "lastColumn" : "lastColumn")
                     .WithValueExpression((i, c) => c.UrlHelper.Action("detail", new { id = i.Id }))
                     .WithValueTemplate("<a id='edit' href='#' data-urlStructure='/GasAndOil/Edit' data-id='{Model.Id}' data-cust-id='{Model.CustomerId}' data-urlData='/GasAndOil/EditData/{Model.Id}' onClick='return editRow(this)'><span class='glyphicon glyphicon-edit'></span></a>" + "&nbsp;"
                     + "<a href='/GasAndOil/Details/{Model.Id}'><span class='glyphicon glyphicon-list-alt'></span></a>" + "&nbsp;"
                     + "<a href='/GasAndOil/Delete/{Model.Id}'><span class='glyphicon glyphicon-trash'></span></a>", false)
                     .WithPlainTextValueExpression(p => p.Id.ToString());
            })
    .WithRetrieveDataMethod((context) =>
    {
        var options = context.QueryOptions;
        int totalRecords;
        var repo = DependencyResolver.Current.GetService<IGasAndOilService>();
        string globalSearch = options.GetAdditionalQueryOptionString("search");
        string sortColumn = options.GetSortColumnData<string>();
        var items = repo.GetData(out totalRecords, globalSearch, options.GetLimitOffset(), options.GetLimitRowcount(),
        sortColumn, options.SortDirection == SortDirection.Dsc);
        return new QueryResult<GasAndOil>()
        {
            Items = items,
            TotalRecords = totalRecords
        };
    })
  );

        }
    }
}