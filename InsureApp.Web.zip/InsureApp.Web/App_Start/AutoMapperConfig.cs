﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using InsureApp.Data;
using InsureApp.ViewModel;

namespace InsureApp.Web.App_Start
{
    public class AutoMapperConfig
    {
        public static MapperConfiguration configuration = new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<PrivateCustomerDto, Customer>().ReverseMap();

            cfg.CreateMap<CorporateCustomerDto, Customer>().ReverseMap();

            cfg.CreateMap<AviationDto, Aviation>().ReverseMap();

            cfg.CreateMap<AgentDto, Agent>().ReverseMap();

            cfg.CreateMap<AgentContactDto, AgentContact>().ReverseMap();

            cfg.CreateMap<BondDto, Bond>().ReverseMap();

            cfg.CreateMap<ContactPersonDto, ContactPerson>().ReverseMap();

            cfg.CreateMap<FireDto, Fire>().ReverseMap();

            cfg.CreateMap<GeneralAccidentDto, GeneralAccident>().ReverseMap();

            cfg.CreateMap<MarineCargoDto, MarineCargo>().ReverseMap();

            cfg.CreateMap<MarineHullDto, MarineHull>().ReverseMap();

            cfg.CreateMap<OrgStructureNameDto, OrgStructureName>().ReverseMap();

            cfg.CreateMap<OrgStructureValueDto, OrgStructureValue>().ReverseMap();

            cfg.CreateMap<RiskProfileDto, RiskProfile>().ReverseMap();

            cfg.CreateMap<TravelAndHealthDto, TravelAndHealth>().ReverseMap();

            cfg.CreateMap<MiscSetUpNameDto, MiscSetUpName>().ReverseMap();

            cfg.CreateMap<MiscSetUpValueDto, MiscSetUpValue>().ReverseMap();

            cfg.CreateMap<MotorDto, Motor>().ReverseMap();

            cfg.CreateMap<MotorCoInsuranceDto, MotorCoInsurance>().ReverseMap();

            cfg.CreateMap<MotorExtensionDiscountDto, MotorExtensionDiscount>().ReverseMap();

            cfg.CreateMap<DriverDetailDto, DriverDetail>().ReverseMap();

            cfg.CreateMap<LiabilityDto, Liability>().ReverseMap();

            cfg.CreateMap<GasAndOilDto, GasAndOil>().ReverseMap();

            cfg.CreateMap<EngineeringDto, Engineering>().ReverseMap();

            cfg.CreateMap<VehicleRateDto, VehicleRate>().ReverseMap();

            cfg.CreateMap<CoInsuranceDto, CoInsurance>().ReverseMap();

            cfg.CreateMap<ExtensionDiscountDto, ExtensionDiscount>().ReverseMap();

            cfg.CreateMap<FireCoInsuranceDto, FireCoInsurance>().ReverseMap();

            cfg.CreateMap<FireExtensionDiscountDto, FireExtensionDiscount>().ReverseMap();
        });
    }
}