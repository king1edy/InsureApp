﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using InsureApp.Data;
using InsureApp.ViewModel;

namespace InsureApp.Web.App_Start
{
    public class AutoMapperConfig
    {
        public static MapperConfiguration configuration = new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<PrivateCustomerDto, Customer>().ReverseMap();

            cfg.CreateMap<CorporateCustomerDto, Customer>().ReverseMap();

            cfg.CreateMap<AviationDto, Aviation>().ReverseMap();

            cfg.CreateMap<AgentDto, Agent>().ReverseMap();

            cfg.CreateMap<AgentContactDto, AgentContact>().ReverseMap();

            cfg.CreateMap<BondDto, Bond>().ReverseMap();

            cfg.CreateMap<ContactPersonDto, ContactPerson>().ReverseMap();

            cfg.CreateMap<GeneralAccidentDto, GeneralAccident>().ReverseMap();

            cfg.CreateMap<MarineCargoDto, Marine>().ReverseMap();

            cfg.CreateMap<MarineHullDto, Marine>().ReverseMap();

            cfg.CreateMap<OrgStructureNameDto, OrgStructureName>().ReverseMap();

            cfg.CreateMap<OrgStructureValueDto, OrgStructureValue>().ReverseMap();

            cfg.CreateMap<RiskProfileDto, RiskProfile>().ReverseMap();

            cfg.CreateMap<TravelAndHealthDto, TravelAndHealth>().ReverseMap();

            cfg.CreateMap<MiscSetUpNameDto, MiscSetUpName>().ReverseMap();

            cfg.CreateMap<MiscSetUpValueDto, MiscSetUpValue>().ReverseMap();

            cfg.CreateMap<MotorDto, Motor>().ReverseMap();

            cfg.CreateMap<MotorCoInsuranceDto, MotorCoInsurance>().ReverseMap();

            cfg.CreateMap<MotorExtensionDiscountDto, MotorExtensionDiscount>().ReverseMap();

            cfg.CreateMap<DriverDetailDto, DriverDetail>().ReverseMap();

            cfg.CreateMap<LiabilityDto, Liability>().ReverseMap();

            cfg.CreateMap<GasAndOilDto, GasAndOil>().ReverseMap();

            cfg.CreateMap<EngineeringDto, Engineering>().ReverseMap();

            cfg.CreateMap<VehicleRateDto, VehicleRate>().ReverseMap();

            cfg.CreateMap<CoInsuranceDto, FireCoInsurance>().ReverseMap();
            //cfg.CreateMap<FireCoInsurance, CoInsuranceDto>();

            cfg.CreateMap<ExtensionDiscountDto, FireExtensionDiscount>().ReverseMap();
            //cfg.CreateMap<FireExtensionDiscount, ExtensionDiscountDto>();

            cfg.CreateMap<CoInsuranceDto, AviationCoInsurance>().ReverseMap();

            cfg.CreateMap<ExtensionDiscountDto, AviationExtensionDiscount>().ReverseMap();

            cfg.CreateMap<CoInsuranceDto, BondCoInsurance>().ReverseMap();

            cfg.CreateMap<ExtensionDiscountDto, BondExtensionDiscount>().ReverseMap();

            cfg.CreateMap<CoInsuranceDto, GasAndOilCoInsurance>().ReverseMap();

            cfg.CreateMap<ExtensionDiscountDto, GasAndOilExtensionDiscount>().ReverseMap();

            cfg.CreateMap<CoInsuranceDto, TravelAndHealthCoInsurance>().ReverseMap();

            cfg.CreateMap<ExtensionDiscountDto, TravelAndHealthExtensionDiscount>().ReverseMap();

            // Rough mapping for the Subscription
            cfg.CreateMap<Fire, FireDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.FireCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.FireExtensionDiscounts));

            cfg.CreateMap<FireDto, Fire>().ForMember(dest => dest.FireCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.FireExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<Aviation, AviationDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.AviationCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.AviationExtensionDiscounts));

            cfg.CreateMap<AviationDto, Aviation>().ForMember(dest => dest.AviationExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts))
                .ForMember(dest => dest.AviationCoInsurances, opt => opt.MapFrom(src => src.CoInsurances));

            cfg.CreateMap<Bond, BondDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.BondCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.BondExtensionDiscounts));

            cfg.CreateMap<BondDto, Bond>().ForMember(dest => dest.BondCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.BondExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<GasAndOil, GasAndOilDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.GasAndOilCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.GasAndOilExtensionDiscounts));

            cfg.CreateMap<GasAndOilDto, GasAndOil>().ForMember(dest => dest.GasAndOilCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.GasAndOilExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<TravelAndHealth, TravelAndHealthDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.TravelAndHealthCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.TravelAndHealthExtensionDiscounts));

            cfg.CreateMap<TravelAndHealthDto, TravelAndHealth>().ForMember(dest => dest.TravelAndHealthCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.TravelAndHealthExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));
        });
    }
}