﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using InsureApp.Data;
using InsureApp.ViewModel;

namespace InsureApp.Web.App_Start
{
    public class AutoMapperConfig
    {
        public static MapperConfiguration configuration = new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<PrivateCustomerDto, Customer>().ReverseMap();

            cfg.CreateMap<CorporateCustomerDto, Customer>().ReverseMap();

            cfg.CreateMap<AviationDto, Aviation>().ReverseMap();

            cfg.CreateMap<AgentDto, Agent>().ReverseMap();

            cfg.CreateMap<AgentContactDto, AgentContact>().ReverseMap();

            cfg.CreateMap<BondDto, Bond>().ReverseMap();

            cfg.CreateMap<ContactPersonDto, ContactPerson>().ReverseMap();

            cfg.CreateMap<GeneralAccidentDto, GeneralAccident>().ReverseMap();

            cfg.CreateMap<MarineCargoDto, Marine>().ReverseMap();

            cfg.CreateMap<MarineHullDto, Marine>().ReverseMap();

            cfg.CreateMap<OrgStructureNameDto, OrgStructureName>().ReverseMap();

            cfg.CreateMap<OrgStructureValueDto, OrgStructureValue>().ReverseMap();

            cfg.CreateMap<RiskProfileDto, RiskProfile>().ReverseMap();

            cfg.CreateMap<TravelDto, Travel>().ReverseMap();

            cfg.CreateMap<MiscSetUpNameDto, MiscSetUpName>().ReverseMap();

            cfg.CreateMap<MiscSetUpValueDto, MiscSetUpValue>().ReverseMap();


            // Motor AutoMapper Config...
            cfg.CreateMap<MotorDto, Motor>().ReverseMap();
            cfg.CreateMap<MotorCoInsuranceDto, MotorCoInsurance>().ReverseMap();
            cfg.CreateMap<MotorExtensionDiscountDto, MotorExtensionDiscount>().ReverseMap();

            // Motor Batch Config...
            cfg.CreateMap<MotorBatchDto, MotorBatch>()
                .ForMember(dest => dest.MotorCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.MotorExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));
            cfg.CreateMap<MotorBatch, MotorBatchDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.MotorCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.MotorExtensionDiscounts));
            cfg.CreateMap<CoInsuranceDto, MotorCoInsurance>()
                .ForMember(dest => dest.MotorId, opt => opt.MapFrom(src => src.PolicyId));
            cfg.CreateMap<MotorCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.MotorId));

            cfg.CreateMap<ExtensionDiscountDto, MotorExtensionDiscount>()
                .ForMember(dest => dest.MotorId, opt => opt.MapFrom(src => src.PolicyId));
            cfg.CreateMap<MotorExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.MotorId));


            cfg.CreateMap<DriverDetailDto, DriverDetail>().ReverseMap();

            cfg.CreateMap<LiabilityDto, Liability>().ReverseMap();

            cfg.CreateMap<GasAndOilDto, GasAndOil>().ReverseMap();

            cfg.CreateMap<EngineeringDto, Engineering>().ReverseMap();

            cfg.CreateMap<VehicleRateDto, VehicleRate>().ReverseMap();



            cfg.CreateMap<CoInsuranceDto, FireCoInsurance>()
                .ForMember(dest => dest.FireId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<FireCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.FireId));
            cfg.CreateMap<ExtensionDiscountDto, FireExtensionDiscount>()
                .ForMember(dest => dest.FireId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<FireExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.FireId));


            cfg.CreateMap<CoInsuranceDto, BondCoInsurance>()
                .ForMember(dest => dest.BondId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<BondCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.BondId));
            cfg.CreateMap<ExtensionDiscountDto, BondExtensionDiscount>()
                .ForMember(dest => dest.BondId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<BondExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.BondId));


            cfg.CreateMap<CoInsuranceDto, AviationCoInsurance>()
                .ForMember(dest => dest.AviationId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<AviationCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.AviationId));
            cfg.CreateMap<ExtensionDiscountDto, AviationExtensionDiscount>()
                .ForMember(dest => dest.AviationId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<AviationExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.AviationId));

            cfg.CreateMap<CoInsuranceDto, TravelCoInsurance>()
                .ForMember(dest => dest.TravelId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<TravelCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.TravelId));
            cfg.CreateMap<ExtensionDiscountDto, TravelExtensionDiscount>()
                .ForMember(dest => dest.TravelId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<TravelExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.TravelId));

            cfg.CreateMap<CoInsuranceDto, GasAndOilCoInsurance>()
                .ForMember(dest => dest.GasAndOilId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<GasAndOilCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.GasAndOilId));
            cfg.CreateMap<ExtensionDiscountDto, GasAndOilExtensionDiscount>()
                .ForMember(dest => dest.GasAndOilId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<GasAndOilExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.GasAndOilId));

            cfg.CreateMap<CoInsuranceDto, EngineeringCoInsurance>()
                .ForMember(dest => dest.EngineeringId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<EngineeringCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.EngineeringId));
            cfg.CreateMap<ExtensionDiscountDto, EngineeringExtensionDiscount>()
                .ForMember(dest => dest.EngineeringId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<EngineeringExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.EngineeringId));

            cfg.CreateMap<CoInsuranceDto, MarineCoInsurance>()
                .ForMember(dest => dest.MarineId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<MarineCoInsurance, CoInsuranceDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.MarineId));
            cfg.CreateMap<ExtensionDiscountDto, MarineExtensionDiscount>()
                .ForMember(dest => dest.MarineId, opt => opt.MapFrom(src => src.PolicyId));

            cfg.CreateMap<MarineExtensionDiscount, ExtensionDiscountDto>()
                .ForMember(dest => dest.PolicyId, opt => opt.MapFrom(src => src.MarineId));

            // Rough mapping for the Subscription
            cfg.CreateMap<Fire, FireDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.FireCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.FireExtensionDiscounts));

            cfg.CreateMap<FireDto, Fire>().ForMember(dest => dest.FireCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.FireExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<Aviation, AviationDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.AviationCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.AviationExtensionDiscounts));

            cfg.CreateMap<AviationDto, Aviation>().ForMember(dest => dest.AviationExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts))
                .ForMember(dest => dest.AviationCoInsurances, opt => opt.MapFrom(src => src.CoInsurances));

            cfg.CreateMap<Bond, BondDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.BondCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.BondExtensionDiscounts));

            cfg.CreateMap<BondDto, Bond>().ForMember(dest => dest.BondCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.BondExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<GasAndOil, GasAndOilDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.GasAndOilCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.GasAndOilExtensionDiscounts));

            cfg.CreateMap<GasAndOilDto, GasAndOil>().ForMember(dest => dest.GasAndOilCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.GasAndOilExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<Travel, TravelDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.TravelCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.TravelExtensionDiscounts));

            cfg.CreateMap<TravelDto, Travel>().ForMember(dest => dest.TravelCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.TravelExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<Marine, MarineCargoDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.MarineCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.MarineExtensionDiscounts));

            cfg.CreateMap<MarineCargoDto, Marine>()
                .ForMember(dest => dest.MarineCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.MarineExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<Marine, MarineHullDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.MarineCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.MarineExtensionDiscounts));

            cfg.CreateMap<MarineHullDto, Marine>()
                .ForMember(dest => dest.MarineCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.MarineExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            cfg.CreateMap<Engineering, EngineeringDto>()
                .ForMember(dest => dest.CoInsurances, opt => opt.MapFrom(src => src.EngineeringCoInsurances))
                .ForMember(dest => dest.ExtensionDiscounts, opt => opt.MapFrom(src => src.EngineeringExtensionDiscounts));

            cfg.CreateMap<EngineeringDto, Engineering>()
                .ForMember(dest => dest.EngineeringCoInsurances, opt => opt.MapFrom(src => src.CoInsurances))
                .ForMember(dest => dest.EngineeringExtensionDiscounts, opt => opt.MapFrom(src => src.ExtensionDiscounts));

            // Rough mapping for the  Policy Batches and the Subscription
        });
    }
}