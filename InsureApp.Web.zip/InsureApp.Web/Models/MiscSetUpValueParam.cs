﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsureApp.Web.Models
{
    public class MiscSetUpValueParam
    {
        public string NameId { get; set; }
        public string ParentId { get; set; }
    }
}