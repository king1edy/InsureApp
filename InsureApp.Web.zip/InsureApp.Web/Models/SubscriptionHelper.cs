﻿using AutoMapper;
using InsureApp.Data;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InsureApp.Web.Models
{
    public class SubscriptionHelper : Controller
    {
        public CustomerDto GetCustomerDetails(long CustomerId, ICustomerService customerService, IMapper mapper, long Id)
        {
            Customer obj = null;
            CustomerDto customerDto = new CustomerDto();
            customerDto.PolicyId = Id.ToString();
            try
            {
                obj = customerService.GetAll().Where(m => m.Id == CustomerId).First();
            }
            catch (Exception)
            {
                obj = customerService.GetAll().Where(m => m.CustId == CustomerId).First();
            }

            if (obj.CustomerType == "Private")
            {
                var customer = mapper.Map<PrivateCustomerDto>(obj);
                customer.DOB = Convert.ToDateTime(customer.DOB).ToString("MM/dd/yyyy");
                customerDto.PrivateCustomer = customer;
                customerDto.CustomerType = "Private";
                return customerDto;
            }
            else
            {
                var customer = mapper.Map<CorporateCustomerDto>(obj);
                customer.YearIncorporated = Convert.ToDateTime(customer.YearIncorporated).ToString("MM/dd/yyyy");
                customerDto.CorporateCustomer = customer;
                customerDto.CustomerType = "Corporate";
                return customerDto;
            }
        }
    }
}