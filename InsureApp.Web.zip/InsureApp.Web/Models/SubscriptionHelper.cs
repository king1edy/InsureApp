﻿using AutoMapper;
using InsureApp.Data;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InsureApp.Web.Models
{
    public class SubscriptionHelper : Controller
    {
        public ActionResult GetCustomerDetails(long CustomerId, ICustomerService customerService, IMapper mapper, long Id)
        {
            Customer obj = null;
            try
            {
                obj = customerService.GetAll().Where(m => m.Id == CustomerId).First();
            }
            catch (Exception)
            {
                obj = customerService.GetAll().Where(m => m.CustId == CustomerId).First();
            }

            if (obj.CustomerType == "Private")
            {
                var customer = mapper.Map<PrivateCustomerDto>(obj);
                customer.DOB = Convert.ToDateTime(customer.DOB).ToString("MM/dd/yyyy");
                ViewBag.PrivateCustomerDto = customer;
                ViewBag.Id = Id;
                return PartialView("Create");
            }
            else
            {
                var customer = mapper.Map<CorporateCustomerDto>(obj);
                customer.YearIncorporated = Convert.ToDateTime(customer.YearIncorporated).ToString("MM/dd/yyyy");
                ViewBag.CorporateCustomerDto = customer;
                ViewBag.Id = Id;
                return PartialView("Create");
            }
        }
    }
}