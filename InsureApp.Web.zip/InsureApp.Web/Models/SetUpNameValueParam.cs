﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsureApp.Web.Models
{
    public class SetUpNameValueParam
    {
        public string SetUpName { get; set; }
        public string ParentId { get; set; }
        public string AgentClass { get; set; }
        public string AgentType { get; set; }
        public string Status { get; set; }
        public string TransactionCurrency { get; set; }
        public string CommissionClass { get; set; }
    }
}