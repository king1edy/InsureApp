﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InsureApp.Web.Models
{
    public class OrgStructureValueParam
    {
        public string NameId { set; get; }
        public string ParentId { set; get; }
    }
}