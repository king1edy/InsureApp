﻿function info(travel) {
    this.id = travel != null ? travel.id : '';
    this.customerId = travel != null ? travel.customerId : '';
    this.itemNumber = travel != null ? travel.itemNumber : '';
    this.travelCertificate = travel != null ? travel.travelCertificate : '';
    this.passportNumber = travel != null ? travel.passportNumber : '';
    this.numberOfTravellers = travel != null ? travel.numberOfTravellers : '';
    this.nextOfKin = travel != null ? travel.nextOfKin : '';
    this.nextOfKinAddress = travel != null ? travel.nextOfKinAddress : '';
    this.nextOfKinTelephoneNo = travel != null ? travel.nextOfKinTelephoneNo : '';
    this.destination = travel != null ? travel.destination : '';
    this.travellingDate = travel != null ? travel.travellingDate : '';
    this.returningDate = travel != null ? travel.returningDate : '';
    this.businessOccupation = travel != null ? travel.businessOccupation : '';
    this.excess = travel != null ? travel.excess : '';
    this.sumInsured = travel != null ? travel.sumInsured : '';
    this.premiumOrRate = travel != null ? travel.premiumOrRate : '';
    this.prorataDays = travel != null ? travel.prorataDays : '';
    this.proratePremium = travel != null ? travel.proratePremium : '';
    this.lastClaimDate = travel != null ? travel.lastClaimDate : '';
    this.riskProfile = travel != null ? travel.riskProfile : '';
    this.policyNumber = travel != null ? travel.policyNumber : '';

    this.coInsurances = travel != null ? travel.coInsurances : [];
    this.extensionDiscounts = travel != null ? travel.extensionDiscounts : [];
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    destinations: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'destination', 'parentId': null }, 'setUpValues', false),
    businessOccupations: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'business occupation', 'parentId': null }, 'setUpValues', false),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    extensionTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'extension types', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'policy type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'insurance companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    var travelId = $('#hdTravel').val();
    var customerId = $('#hdCustomer').val();


    //infoViewModel.customer = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', { custId: custId }, 'customerData', false);

    //for a new Agent Registration
    if (travelId == 0) {
        infoViewModel.info = new info(null);
    }

    //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Travel/EditData/',
            contentType: "application/json",
            type: "GET",
            data: { id : travelId },
            success: function (data) {
                infoViewModel.info = data;
            }
        });
    }

    infoViewModel.info.customerId = customerId;

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal');
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal');
            }
        }
    })

    validate();
});

function validate() {
    $form = $('#travel').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
    fields: {
        travelCertificate: {
            validators: {
                notEmpty: {
                    message: '<strong>Travel Certificate</strong> required'
                }
            }
        },
        passportNumber: {
            validators: {
                notEmpty: {
                    message: '<strong>Passport Number</strong> required'
                }
            }
        },
        numberOfTravellers: {
            validators: {
                notEmpty: {
                    message: '<strong>Number of Travellers</strong> required'
                }
            }
        },
        nextOfKin: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin</strong> required'
                }
            }
        },
        nextOfKinAddress: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin Address </strong> required'
                }
            }
        },
        nextOfKinTelephone: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin Telephone </strong> required'
                }
            }
        },
        destination: {
            validators: {
                notEmpty: {
                    message: '<strong>Destination </strong>required'
                }
            }
        },
        travellingDate: {
            validators: {
                notEmpty: {
                    message: '<strong>Travelling Date </strong> required'
                }
            }

        },
        returningDate: {
            validators: {
                notEmpty: {
                    message: '<strong>Returning Date </strong> required'
                }
            }
        },
        businessOccupation: {
            validators: {
                notEmpty: {
                    message: '<strong>Business Occupation</strong> required'
                }
            }
        },
        itemNumber: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin</strong> required'
                }
            }
        },
        excess: {
            validators: {
                notEmpty: {
                    message: '<strong>Excess </strong> required'
                }
            }
        },
        sumInsured: {
            validators: {
                notEmpty: {
                    message: '<strong>Sum Insured</strong> required'
                }
            }
        },
        premiumOrRate: {
            validators: {
                notEmpty: {
                    message: '<strong>Premium or Rate </strong> required'
                }
            }
        },
        prorataDays: {
            validators: {
                notEmpty: {
                    message: '<strong>Prorata Days </strong> required'
                }
            }
        },
        proratePremium: {
            validators: {
                notEmpty: {
                    message: '<strong>Prorate Premium </strong> required'
                }
            }
        },
        lastClaimDate: {
            validators: {
                notEmpty: {
                    message: '<strong>Last Claim Date </strong> required'
                }
            }
        },
        riskProfile: {
            validators: {
                notEmpty: {
                    message: '<strong>Risk profile field </strong> required'
                }
            }
        }
    },
      policyNumber: {
         validators: {
             notEmpty: {
                message: '<strong>Policy Number </strong> required'
            }
        }
    },
    onSuccess: function (e) {
        e.preventDefault();
        submitFn.saveData(new info(null), 'travel/Create');
        submitFn.clearFields('travel');
    },
    onError: function (e) {
    e.preventDefault();
        }
    })

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.coInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.coInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            type: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentage: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.extensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.extensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}
