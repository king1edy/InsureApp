﻿function info(engineering) {
    this.id = engineering != null ? engineering.id : '';
    this.customerId = engineering != null ? engineering.customerId : '';
    this.insuredInterest = engineering != null ? engineering.insuredInterest : '';
    this.engineNumber = engineering != null ? engineering.engineNumber : '';
    this.modelNumber = engineering != null ? engineering.modelNumber : '';
    this.geographicalLimit = engineering != null ? engineering.geographicalLimit : '';
    this.businessType = engineering != null ? engineering.businessType : '';
    this.principal = engineering != null ? engineering.principal : '';
    this.principalAddress = engineering != null ? engineering.principalAddress : '';
    this.contractProject = engineering != null ? engineering.contractProject : '';
    this.excess = engineering != null ? engineering.excess : '';
    this.maintenancePeriod = engineering != null ? engineering.maintenancePeriod : '';
    this.commissionPeriod = engineering != null ? engineering.commissionPeriod : '';
    this.testingPeriod = engineering != null ? engineering.testingPeriod : '';
    this.constructionPeriod = engineering != null ? engineering.constructionPeriod : '';
    this.itemNumber = engineering != null ? engineering.itemNumber : '';
    this.effectiveDate = engineering != null ? engineering.effectiveDate : '';
    this.sumInsured = engineering != null ? engineering.sumInsured : '';
    this.prorataDays = engineering != null ? engineering.prorataDays : '';
    this.proratePremium = engineering != null ? engineering.proratePremium : '';
    this.lastClaimDate = engineering != null ? engineering.lastClaimDate : '';
    this.entryDate = engineering != null ? engineering.entryDate : '';
    this.riskProfile = engineering != null ? engineering.riskProfile : '';
    this.premiumOrRate = engineering != null ? engineering.premiumOrRate : '';

    this.coInsurances = engineering != null ? engineering.coInsurances : [];
    this.extensionDiscounts = engineering != null ? engineering.extensionDiscounts : [];
}


var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    businessTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'business type', 'parentId': null }, 'setUpValues', false),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    extensionTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'extension types', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'policy type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'insurance companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    var EngineeringId = $('#hdEngineering').val();
    var customerId = $('#hdCustomer').val();

    //for a new Agent Registration
    if (EngineeringId == 0) {
        infoViewModel.info = new info(null);
    }

    //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Engineering/EditData/' + EngineeringId,
            contentType: "application/json",
            type: "GET",
            success: function (data) {
                infoViewModel.info = data;
                console.log(JSON.stringify(infoViewModel.info));
            }
        });
    }

    infoViewModel.info.customerId = customerId;

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal')
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal')
            }
        }
    })

    validate();
});

function validate() {
        $('#engineering').bootstrapValidator({
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                insuredInterest: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Insured Interest</strong> required'
                        }
                    }
                },
                engineNumber: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Engine Number</strong> required'
                        },
                        stringLength: {
                            max: 200,
                            message: '<strong>Engine Number</strong> must be less than 200 characters long'
                        }
                    }
                },
                modelNumber: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Model Number</strong> required'
                        },
                        stringLength: {
                            max: 200,
                            message: '<strong>Model Number</strong> must be less than 200 characters long'
                        }
                    }
                },
                geographicalLimit: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Geographical Limit</strong> required'
                        }
                    }
                },
                businessType: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Business Type</strong> required'
                        }
                    }
                },
                principal: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Principal</strong> required'
                        }
                    }
                },
                principalAddress: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Principal Address</strong> required'
                        },
                        stringLength: {
                            max: 200,
                            message: '<strong>Principal Address</strong> must be less than 200 characters long'
                        }
                    }
                },
                contractProject: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Contract Project</strong> required'
                        },
                        stringLength: {
                            max: 200,
                            message: '<strong>Contract Project</strong> must be less than 200 characters long'
                        }
                    }
                },
                maintenancePeriod: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Maintenance Period</strong> required'
                        }
                    }
                },
                commissionPeriod: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Commision Period</strong> required'
                        }
                    }
                },
                testingPeriod: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Testing Period</strong> required'
                        }
                    }
                },
                constructionPeriod: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Construction Period</strong> required'
                        }
                    }
                },
                additionalInsured: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Additional Insured</strong> required'
                        },
                        stringLength: {
                            max: 50,
                            message: '<strong>Additional Insured</strong> must be less than 50 characters long'
                        }
                    }
                },
                itemNumber: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Item Number</strong> required'
                        },
                        stringLength: {
                            max: 50,
                            message: '<strong>Item Number</strong> must be less than 50 characters long'
                        }
                    }
                },
                effectiveDate: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Effective Date</strong> required'
                        }
                    }
                },
                excess: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Excess</strong> required'
                        }
                    }
                },
                sumInsured: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Sum Insured</strong> required'
                        }
                    }
                },
                premiumOrRate: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Premium or Rate</strong> required'
                        }
                    }
                },
                prorataDays: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Prorata Days</strong> required'
                        }
                    }
                },
                proratePremium: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Prorate Premium</strong> required'
                        }
                    }
                },
                extensionOrDiscount: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Discount</strong> required'
                        }
                    }
                },
                lastClaimDate: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Last Claim Date</strong> required'
                        },
                    }
                },
                
                entryDate: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Entry Date</strong> required'
                        },
                    }
                },
                riskProfile: {
                    validators: {
                        notEmpty: {
                            message: '<strong>Risk Profile</strong> Required'
                        }
                    }
                }
            },
            onSuccess: function (e) {
                e.preventDefault();
                console.log(JSON.stringify(app.vm.info));
                submitFn.saveData(new info(null), 'Engineering/Create');
                submitFn.clearFields('engineering');
            },
            onError: function (e) {
                e.preventDefault();
            }
        })

        //TODO: Validation for Co-Insurance sub-form
        $('#coInsuranceForm').bootstrapValidator({
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                policyNumber: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                participant: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                sumInsured: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                isPrincipal: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                premium: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                percentageShare: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                policyType: {
                    validators: {
                        notEmpty: {
                        }
                    }
                }
            },
            onSuccess: function (e) {
                e.preventDefault();
                populateCoInsurance(app.vm.coInsurance);
                submitFn.successAlert();
                $("#coInsuranceForm").bootstrapValidator('resetForm', true);
                app.vm.coInsurance = new coInsurance(null);
            },
            onError: function (e) {
                e.preventDefault();
            }
        })

        //TODO: Validation for Extension Discount sub-form

        $('#extensionDiscountForm').bootstrapValidator({
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                policyNumber: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                description: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                type: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                percentage: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                applyTo: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                isExcluded: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                amount: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                currentNet: {
                    validators: {
                        notEmpty: {
                        }
                    }
                },
                policyType: {
                    validators: {
                        notEmpty: {
                        }
                    }
                }
            },
            onSuccess: function (e) {
                e.preventDefault();
                populateExtensionDiscounts(app.vm.extensionDiscount);
                submitFn.successAlert();
                $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
                app.vm.extensionDiscount = new extensionDiscount(null);
            },
            onError: function (e) {
                e.preventDefault();
            }
        })
    }