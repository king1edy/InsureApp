﻿function info(motorBatch) {
    this.id = motorBatch != null ? motorBatch.id : '';
    this.references = motorBatch != null ? motorBatch.references : '';
    this.noOfRecords = motorBatch != null ? motorBatch.noOfRecords : '';
    this.processingDate = motorBatch != null ? motorBatch.processingDate : '';
    this.uploadDate = motorBatch != null ? motorBatch.uploadDate : '';
    this.uploadBy = motorBatch != null ? motorBatch.uploadBy : '';
    this.status = motorBatch != null ? motorBatch.status : '';

    this.coInsurances = motorBatch != null ? motorBatch.coInsurances : [];
    this.extensionDiscounts = motorBatch != null ? motorBatch.extensionDiscounts : [];
    this.motors = motorBatch != null ? motorBatch.motors : [];
}

function motor(motor) {
    this.id = motor != null ? motor.id : '';
    this.vehicleRegistrationNo = motor != null ? motor.vehicleRegistrationNo : '';
    this.customerId = motor != null ? motor.customerId : '';
    this.effectiveDate = motor != null ? motor.effectiveDate : '';
    this.itemNumber = motor != null ? motor.itemNumber : '';
    this.vehicleMake = motor != null ? motor.vehicleMake : '';
    this.vehicleModel = motor != null ? motor.vehicleModel : '';
    this.typeOfBody = motor != null ? motor.typeOfBody : '';
    this.horsePower = motor != null ? motor.horsePower : '';
    this.color = motor != null ? motor.color : '';
    this.inspectionDate = motor != null ? motor.inspectionDate : '';
    this.fleetNumber = motor != null ? motor.fleetNumber : '';
    this.cubicCapacity = motor != null ? motor.cubicCapacity : '';
    this.yearOfMake = motor != null ? motor.yearOfMake : '';
    this.additionalInsured = motor != null ? motor.additionalInsured : '';
    this.numberOfSit = motor != null ? motor.numberOfSit : '';
    this.certificateType = motor != null ? motor.certificateType : '';
    this.engineNumber = motor != null ? motor.engineNumber : '';
    this.chasisNumber = motor != null ? motor.chasisNumber : '';
    this.excess = motor != null ? motor.excess : '';
    this.sumInsured = motor != null ? motor.sumInsured : '';
    this.premiumOrRate = motor != null ? motor.premiumOrRate : '';
    this.prorataDays = motor != null ? motor.prorataDays : '';
    this.proratePremium = motor != null ? motor.proratePremium : '';
    this.lastClaimDate = motor != null ? motor.lastClaimDate : '';
    this.riskProfile = motor != null ? motor.riskProfile : '';
    this.coverPeriodTo = motor != null ? motor.coverPeriodTo : '';
    this.coverPeriodFrom = motor != null ? motor.coverPeriodFrom : '';
    this.coverageType = motor != null ? motor.coverageType : '';
}

var infoViewModel = {
    info: new info(null),
    motor: new motor(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    extensionTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Extension Types', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Insurance Companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    //var MotorId = $('#hdMotor').val();
    var custId = $('#hdCustomer').val();

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true,
            showCancelBtn: false,
            validateCsvBtn: false,
            tabCtrl: false,
            submitBtn: false,
            proceedBtn: false,
            dialogMsg: true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal')
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal')
            }
        }
    })

    validate();
});

//returns screen to the grid display of corporate customers
$('#btnBackToAgent').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', null);
    myAjaxCall();
});

$("#btnSubmit").on('click', function (e) {
    e.preventDefault();
    
    submitFn.saveDataMultiple('Motor/CreateMultiple', 'batchItems', 'fileInput');
})

function validate() {

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Number</strong> Required'
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                        message: '<strong>Participant</strong> Required'
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                        message: '<strong>Sum Insured</strong> Required'
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                        message: '<strong>Is Principal</strong> Required'
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                        message: '<strong>Premium</strong> Required'
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                        message: '<strong>Percentage Share</strong> Required'
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Type</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.coInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.coInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Number</strong> Required'
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                        message: '<strong>Description</strong> Required'
                    }
                }
            },
            //type: {
            //    validators: {
            //        notEmpty: {
            //            message: '<strong>Type</strong> Required'
            //        }
            //    }
            //},
            percentage: {
                validators: {
                    notEmpty: {
                        message: '<strong>Percentage</strong> Required'
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                        message: '<strong>Apply To</strong> Required'
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                        message: '<strong>Is Excluded?</strong> Required'
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                        message: '<strong>Amount</strong> Required'
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                        message: '<strong>Current Net</strong> Required'
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Type</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.extensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.extensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}