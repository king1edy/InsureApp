﻿// read a CSV file
var csvParser = new SimpleExcel.Parser.CSV();
var fileInput = document.getElementById('fileInput');
myDataTable = null;
var globalCounter = errorCount = 0;
var errorList = [];

// parse when file loaded, then print the result to console
fileInput.addEventListener('change', function (e) {
    var file = e.target.files[0];

    csvParser.loadFile(file, function () {
        var items = [];
        var rows = csvParser.getSheet().length;
        for (var a = 2; a < rows; ++a) {
            var motor = {
                Id: null,
                CustomerId: csvParser.getSheet().getCell(1, a).value,
                VehicleRegistrationNo: csvParser.getSheet().getCell(2, a).value,
                EffectiveDate: csvParser.getSheet().getCell(3, a).value,
                ItemNumber: parseInt(csvParser.getSheet().getCell(4, a).value) + 1,
                VehicleMake: csvParser.getSheet().getCell(5, a).value,
                VehicleModel: csvParser.getSheet().getCell(6, a).value,
                TypeOfBody: csvParser.getSheet().getCell(7, a).value,
                HorsePower: csvParser.getSheet().getCell(8, a).value,
                Color: csvParser.getSheet().getCell(9, a).value,
                InspectionDate: csvParser.getSheet().getCell(10, a).value,
                FleetNumber: csvParser.getSheet().getCell(11, a).value,
                CubicCapacity: csvParser.getSheet().getCell(12, a).value,
                YearOfMake: csvParser.getSheet().getCell(13, a).value,
                AdditionalInsured: csvParser.getSheet().getCell(14, a).value,
                NumberOfSit: csvParser.getSheet().getCell(15, a).value,
                CertificateType: csvParser.getSheet().getCell(16, a).value,
                EngineNumber: csvParser.getSheet().getCell(17, a).value,
                ChasisNumber: csvParser.getSheet().getCell(18, a).value,
                Excess: csvParser.getSheet().getCell(19, a).value,
                SumInsured: csvParser.getSheet().getCell(20, a).value,
                PremiumOrRate: csvParser.getSheet().getCell(21, a).value,
                ProrataDays: csvParser.getSheet().getCell(22, a).value,
                ProratePremium: csvParser.getSheet().getCell(23, a).value,
                LastClaimDate: csvParser.getSheet().getCell(24, a).value,
                RiskProfile: csvParser.getSheet().getCell(25, a).value,
                EntryDate: csvParser.getSheet().getCell(26, a).value,
                CoverageType: csvParser.getSheet().getCell(27, a).value,
                CoverPeriodTo: csvParser.getSheet().getCell(28, a).value,
                CoverPeriodFrom: csvParser.getSheet().getCell(29, a).value,
                Status: ''
            }
            items.push(motor);
        }
        app.vm.info.motors = items;
        loadData();
    });
});

function loadData(items) {

    myDataTable = $("#batchItems").DataTable({
        "aaData": app.vm.info.motors,
        columns: [
            { title: "Customer Id" },
            { title: "Vehicle Registration No" },
            { title: "Effective Date" },
            { title: "Item Number" },
            { title: "Vehicle Make" },
            { title: "Vehicle Model" },
            { title: "Type Of Body" },
            { title: "Horse Power" },
            { title: "Color" },
            { title: "Inspection Date" },
            { title: "Fleet Number" },
            { title: "Cubic Capacity" },
            { title: "Year Of Make" },
            { title: "Additional Insured" },
            { title: "Number Of Sit" },
            { title: "Certificate Type" },
            { title: "Engine Number" },
            { title: "Chasis Number" },
            { title: "Excess" },
            { title: "Sum Insured" },
            { title: "Premium Or Rate" },
            { title: "Prorata Days" },
            { title: "Prorate Premium" },
            { title: "Last Claim Date" },
            { title: "Risk Profile" },
            { title: "Entry Date" },
            { title: "Coverage Type" },
            { title: "Cover Period From" },
            { title: "Cover Period To" },
            { title: "Status" }
        ],
        "aoColumns": [
            { "mData": "CustomerId", "sTitle": "Customer Id", "bSortable": false },
            { "mData": "VehicleRegistrationNo", "sTitle": "Vehicle Registration No", "bSortable": true, "bSearchable": true },
            { "mData": "EffectiveDate", "sTitle": "Effective Date", "bSortable": true, "bSearchable": false },
            { "mData": "ItemNumber", "sTitle": "Item Number", "bSortable": false, "bSearchable": false },
            { "mData": "VehicleMake", "sTitle": "Vehicle Make", "bSortable": true, "bSearchable": true },
            { "mData": "VehicleModel", "sTitle": "Vehicle Modal", "bSortable": true, "bSearchable": true },
            { "mData": "TypeOfBody", "sTitle": "Type Of Vehicle", "bSortable": true, "bSearchable": true },
            { "mData": "HorsePower", "sTitle": "Horse Power", "bSortable": false, "bSearchable": false },
            { "mData": "Color", "sTitle": "Color", "bSortable": false, "bSearchable": true },
            { "mData": "InspectionDate", "sTitle": "Inspection Date", "bSortable": true, "bSearchable": false },
            { "mData": "FleetNumber", "sTitle": "Fleet Number", "bSortable": false, "bSearchable": false },
            { "mData": "CubicCapacity", "sTitle": "Cubic Capacity", "bSortable": false, "bSearchable": false },
            { "mData": "YearOfMake", "sTitle": "Year Of Make", "bSortable": false, "bSearchable": true },
            { "mData": "AdditionalInsured", "sTitle": "Additional Insured", "bSortable": false, "bSearchable": false },
            { "mData": "NumberOfSit", "sTitle": "Number Of Sit", "bSortable": false, "bSearchable": false },
            { "mData": "CertificateType", "sTitle": "Certificate Type", "bSortable": false, "bSearchable": true },
            { "mData": "EngineNumber", "sTitle": "Engine Number", "bSortable": false, "bSearchable": true },
            { "mData": "ChasisNumber", "sTitle": "Chasis Number", "bSortable": false, "bSearchable": true },
            { "mData": "Excess", "sTitle": "Excess", "bSortable": false, "bSearchable": false },
            { "mData": "SumInsured", "sTitle": "Sum Insured", "bSortable": false, "bSearchable": false },
            { "mData": "PremiumOrRate", "sTitle": "Premium Or Rate", "bSortable": false, "bSearchable": false },
            { "mData": "ProrataDays", "sTitle": "Prorata Days", "bSortable": false, "bSearchable": false },
            { "mData": "ProratePremium", "sTitle": "Prorate Premimum", "bSortable": false, "bSearchable": false },
            { "mData": "LastClaimDate", "sTitle": "Last Claim Date", "bSortable": false, "bSearchable": false },
            { "mData": "RiskProfile", "sTitle": "Risk Profile", "bSortable": false, "bSearchable": true },
            { "mData": "EntryDate", "sTitle": "Entry Date", "bSortable": true, "bSearchable": false },
            { "mData": "CoverageType", "sTitle": "Coverage Type", "bSortable": true, "bSearchable": false },
            { "mData": "CoverPeriodFrom", "sTitle": "Cover Period From", "bSortable": true, "bSearchable": false },
            { "mData": "CoverPeriodTo", "sTitle": "Cover Period To", "bSortable": true, "bSearchable": false },
            { "mData": "Status", "sTitle": "Status", "bSortable": true, "bSearchable": false }
        ],
        "drawCallback": function (settings) {
            app.validateCsvBtn = true;
        }
    });
}

function validate(count, item, noOfRows) {
    var isSuccess = false;
    $.ajax({
        url: "/Motor/Validate",
        data: item,
        method: "GET",
        async: true,
        success: function (data) {
            isSuccess = data.data.Status;
            if (!isSuccess) {
                ++errorCount;
                errorList.push(data.data);
            }
        },
        complete: function (data) {
            ++globalCounter;
            updateProgress(noOfRows);
        }
    })
    return {
        "success": isSuccess
    }
}

$('#btnValidate').on('click', function (e) {
    initializeDialog();
    $('#validateModal').modal('show');
    var allData = myDataTable.rows().data();
    var noOfRows = allData.length;
    for (var count = 0; count < noOfRows; ++count) {
        var status = validate(count, allData[count], noOfRows);
        allData[count].status = status;
    }
    return false;
});

function updateProgress(totalRecords) {
    var percentage = Math.round((globalCounter / (totalRecords - 1) * 100)) + "%";
    $(".progress-bar").width(percentage);
    if (globalCounter == totalRecords) {
        $(".modal-title").html('Validation Complete');
        $("#message").css("display", "block");
        $("#lblTotalRecords").html(totalRecords);
        $("#lblErrorRecords").html(errorCount);
        $('#lblSuccessfulRecords').html(totalRecords - errorCount);
        //update the data table to display failure status;
        app.dialogMsg = false;
        if (errorList.length > 0) {
            app.showCancelBtn = true;
            app.proceedBtn = false;
            for (var counter = 0; counter < errorList.length; ++counter) {
                setRowErrorStaus(errorList[counter]);
            }
        } else {
            app.showCancelBtn = false
            app.proceedBtn = true;
        }
    }
}

function initializeDialog() {
    globalCounter = errorCount = 0;
    errorList = [];
    $(".progress-bar").width(0);
    $(".modal-title").html('Batch Validation');
    $("#message").css("display", "none");
}

function setRowErrorStaus(obj) {
    myDataTable.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        if (data.VehicleRegistrationNo == obj.VehicleRegistrationNo) {
            d.status = obj.Status;
            this.invalidate(); // invalidate the data DataTables has cached for this row
        }
    });
    // Draw once all updates are done
    myDataTable.draw();
}

$("#btnProceed").on('click', function (e) {
    e.preventDefault();
    app.submitBtn = true;
    app.validateCsvBtn = false;
    $("#validateModal").modal('hide');
});

