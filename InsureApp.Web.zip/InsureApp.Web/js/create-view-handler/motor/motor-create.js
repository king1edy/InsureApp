﻿function info(motor) {
    this.id = motor != null ? motor.id : '';
    this.vehicleRegistrationNo = motor != null ? motor.vehicleRegistrationNo : '';
    this.customerId = motor != null ? motor.customerId : '';
    this.effectiveDate = motor != null ? motor.effectiveDate : '';
    this.itemNumber = motor != null ? motor.itemNumber : '';
    this.vehicleMake = motor != null ? motor.vehicleMake : '';
    this.vehicleModel = motor != null ? motor.vehicleModel : '';
    this.typeOfBody = motor != null ? motor.typeOfBody : '';
    this.horsePower = motor != null ? motor.horsePower : '';
    this.color = motor != null ? motor.color : '';
    this.inspectionDate = motor != null ? motor.inspectionDate : '';
    this.fleetNumber = motor != null ? motor.fleetNumber : '';
    this.cubicCapacity = motor != null ? motor.cubicCapacity : '';
    this.yearOfMake = motor != null ? motor.yearOfMake : '';
    this.additionalInsured = motor != null ? motor.additionalInsured : '';
    this.numberOfSit = motor != null ? motor.numberOfSit : '';
    this.certificateType = motor != null ? motor.certificateType : '';
    this.engineNumber = motor != null ? motor.engineNumber : '';
    this.chasisNumber = motor != null ? motor.chasisNumber : '';
    this.excess = motor != null ? motor.excess : '';
    this.sumInsured = motor != null ? motor.sumInsured : '';
    this.premiumOrRate = motor != null ? motor.premiumOrRate : '';
    this.prorataDays = motor != null ? motor.prorataDays : '';
    this.proratePremium = motor != null ? motor.proratePremium : '';
    this.lastClaimDate = motor != null ? motor.lastClaimDate : '';
    this.riskProfile = motor != null ? motor.riskProfile : '';
    this.coverPeriodTo = motor != null ? motor.coverPeriodTo : '';
    this.coverPeriodFrom = motor != null ? motor.coverPeriodFrom : '';
    this.coverageType = motor != null ? motor.coverageType : '';

    this.driverDetails = motor != null ? motor.driverDetails : [];
    this.motorCoInsurances = motor != null ? motor.motorCoInsurances : [];
    this.motorExtensionDiscounts = motor != null ? motor.motorExtensionDiscounts : [];
}

function driverDetail(driverDetail) {
    this.id = driverDetail != null ? driverDetail.id : '';
    this.customerId = driverDetail != null ? driverDetail.customerId : '';
    this.firstName = driverDetail != null ? driverDetail.firstName : '';
    this.lastName = driverDetail != null ? driverDetail.lastName : '';
    this.dateOfBirth = driverDetail != null ? driverDetail.dateOfBirth : '';
    this.gender = driverDetail != null ? driverDetail.gender : '';
    this.licenseType = driverDetail != null ? driverDetail.licenseType : '';
    this.relationshipToProposer = driverDetail != null ? driverDetail.relationshipToProposer : '';
    this.occupation = driverDetail != null ? driverDetail.occupation : '';
    this.isMainDriver = driverDetail != null ? driverDetail.isMainDriver : '';
    this.yearOfDrivingExperience = driverDetail != null ? driverDetail.yearOfDrivingExperience : '';
    this.licenseNumberOfRevokedLicense = driverDetail != null ? driverDetail.licenseNumberOfRevokedLicense : '';
    this.revokedLincenseExpiration = driverDetail != null ? driverDetail.revokedLincenseExpiration : '';
    this.licenseNumber = driverDetail != null ? driverDetail.licenseNumber : '';
    this.accidentRecord = driverDetail != null ? driverDetail.accidentRecord : '';
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    driverDetail: new driverDetail(null),
    motorCoInsurance: new coInsurance(null),
    motorExtensionDiscount: new extensionDiscount(null),
    vehicleMakes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Vehicle Make', 'parentId': null }, 'setUpValues', false),
    vehicleModels: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Vehicle Model', 'parentId': null }, 'setUpValues', false),
    typeOfBodies: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Type Of Body', 'parentId': null }, 'setUpValues', false),
    horsePowers: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Horse Power', 'parentId': null }, 'setUpValues', false),
    relationshipToProposers: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Relationship', 'parentId': null }, 'setUpValues', false),
    types: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Extension Types', 'parentId': null }, 'setUpValues', false),
    licenseTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'License Type', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Policy Type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Insurance Companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    var MotorId = $('#hdMotor').val();
    var customerId = $('#hdCustomer').val();

    infoViewModel.customer = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', { customerId: customerId }, 'customerData', false);
    //for a new Agent Registration
    if (MotorId == 0) {
        infoViewModel.info = new info(null);
    }

        //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Motor/EditData/',
            contentType: "application/json",
            type: "GET",
            data: {motorId : MotorId},
            success: function (data) {
                var stateDropDown = new GetDropDownData();
                stateDropDown.load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': data.nationality }, 'states', 'setUpValues', false);
                infoViewModel.info = data;
            }
        });
    }
    infoViewModel.info.customerId = customerId;

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.motorCoInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal')
            },
            callModal2: function () {
                app.vm.motorExtensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal')
            },
            callModal3: function () {
                app.vm.driverDetail = new driverDetail(null);
                submitFn.callModal('driverDetailsModal')
            }
        }
    })

    validate();
});
/*
 * Bootstrap Form Validator 
 */
function validate() {
    //TODO: Validation of the main form
    $('#form').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            vehicleRegistrationNo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            vehicleMake: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            vehicleModel: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            yearOfMake: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            engineNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            chasisNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            color: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            horsePower: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            typeOfBody: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            certificateType: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            numberOfSit: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            inspectionDate: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            fleetNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            cubicCapacity: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            coverPeriodFrom: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            coverPeriodTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            coverageType: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            excess: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            additionalInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premiumOrRate: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            proratePremium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            effectiveDate: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            itemNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            proratadays: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            riskProfile: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            lastClaimDate: {
                validators: {
                    notEmpty: {
                    }
                }
            },
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'Motor/Create');
            submitFn.clearFields('form')
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Number</strong> Required'
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                        message: '<strong>Participant</strong> Required'
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                        message: '<strong>Sum Insured</strong> Required'
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                        message: '<strong>Is Principal</strong> Required'
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                        message: '<strong>Premium</strong> Required'
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                        message: '<strong>Percentage Share</strong> Required'
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Type</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.motorCoInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.motorCoInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Number</strong> Required'
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                        message: '<strong>Description</strong> Required'
                    }
                }
            },
            //type: {
            //    validators: {
            //        notEmpty: {
            //            message: '<strong>Type</strong> Required'
            //        }
            //    }
            //},
            percentage: {
                validators: {
                    notEmpty: {
                        message: '<strong>Percentage</strong> Required'
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                        message: '<strong>Apply To</strong> Required'
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                        message: '<strong>Is Excluded?</strong> Required'
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                        message: '<strong>Amount</strong> Required'
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                        message: '<strong>Current Net</strong> Required'
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                        message: '<strong>Policy Type</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.motorExtensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.motorExtensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Driver sub-form
    $('#addDriverDetails').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            firstName: {
                validators: {
                    notEmpty: {
                        message: '<strong>First Name</strong> Required'
                    }
                }
            },
            lastName: {
                validations: {
                    notEmpty: {
                        message: '<strong>Last Name</strong> Required'
                    }
                }
            },
            gender:{
                validators: {
                    notEmpty: {
                        message: '<Strong>Select a Gender</strong>'
                    }
                }
            },
            licenseType: {
                validators: {
                    notEmpty: {
                        message: '<strong>license Type</strong> Required'
                    }
                }
            },
            relationshipToProposer: {
                validators: {
                    notEmpty: {
                        message: '<strong>Relationship To Proposer</strong> Required'
                    }
                }
            },
            occupation: {
                validators: {
                    notEmpty: {
                        message: '<strong>Occupation is</strong> Required'
                    }
                }
            },
            isMainDriver: {
                validators: {
                    notEmpty: {
                        message: '<strong>Select Yes or No</strong> Required'
                    }
                }
            },
            dateOfBirth: {
                validators: {
                    notEmpty: {
                        message: '<strong>Date Of Birth is</strong> Required'
                    }
                }
            },
            yearOfDrivingExperience: {
                validators: {
                    notEmpty: {
                        message: '<strong>Year Of Driving Experience</strong> Required'
                    }
                }
            },
            licenseRevoked: {
                validators: {
                    notEmpty: {
                        message: '<strong>license Revoked</strong> Required'
                    }
                }
            },
            licenseNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>license Number</strong> Required'
                    }
                }
            },
            accidentRecord: {
                validators: {
                    notEmpty: {
                        message: '<strong>Accident Record</strong> Required'
                    }
                }
            },
            licenseNumberOfRevokedLicense: {
                validators: {
                    notEmpty: {
                        message: '<strong>License Number Of Revoked License</strong> Required'
                    }
                }
            },
            revokedLincenseExpiration: {
                validators: {
                    notEmpty: {
                        message: '<strong>Revoked License Expiration</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateDrivers(app.vm.driverDetail);
            submitFn.successAlert();
            $('#addDriverDetails').bootstrapValidator('resetForm', true);
            app.vm.driverDetail = new driverDetail(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

//sets up the contact person table display for delete operations using javascript's hooks
function contactDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.driverDetails.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.driverDetails.splice(arrayIndex, 1);
        }
    });
}

function contactEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.driverDetails.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.driverDetail = value;
        }
    });
    $('#' + 'driverDetailsModal').modal();
}

function coInsuranceDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.motorCoInsurances.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.motorCoInsurances.splice(arrayIndex, 1);
        }
    });
}

function coInsuranceEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.motorCoInsurances.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.motorCoInsurance = value;
        }
    });
    $('#' + 'coInsuranceModal').modal();
}

function extensionDiscountDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.motorExtensionDiscounts.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.motorExtensionDiscounts.splice(arrayIndex, 1);
        }
    });
}

function extensionDiscountEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.motorExtensionDiscounts.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.motorExtensionDiscount = value;
        }
    });
    $('#' + 'extensionDiscountModal').modal();
}


//returns screen to the grid display of corporate customers
$('#btnBackToAgent').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', null);
    myAjaxCall();
});

//adds contact person to contactPerson Array after checking for duplicates or update request
function populateDrivers(obj) {
    var driverDetail = JSON.parse(JSON.stringify(obj));

    if (driverDetailExist(driverDetail)) {
        return;
    }
    else if (driverDetail.id != '') {
        app.vm.info.driverDetails.forEach(function (value, index) {
            if (driverDetail.id == value.id) {
                value = driverDetail;
            }
        });
    }
    else {
        driverDetail.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.driverDetails.push(driverDetail);
    }
}

//checks to see if contact person already exist
function driverDetailExist(driverDetail) {
    var state = false;
    app.vm.info.driverDetails.forEach(function (value, index) {
        if (driverDetail.id == ''
            && driverDetail.firstName.toLowerCase() == value.firstName.toLowerCase()
            && driverDetail.licenseNumber.toLowerCase() == value.licenseNumber.toLowerCase()) {
            state = true;
        }
    });
    return state;
}

//adds Extension Discount to extensionDiscount Array after checking for duplicates or update request
function populateExtensionDiscounts(obj) {
    var motorExtensionDiscount = JSON.parse(JSON.stringify(obj));
    
    if (motorExtensionDiscountExist(motorExtensionDiscount)) {
        return;
    }
    else if (motorExtensionDiscount.id != '') {
        app.vm.info.motorExtensionDiscounts.forEach(function (value, index) {
            if (motorExtensionDiscount.id == value.id) {
                value = motorExtensionDiscount;
            }
        });
    }
    else {
        motorExtensionDiscount.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.motorExtensionDiscounts.push(motorExtensionDiscount);
    }
}

//checks to see if contact person already exist
function motorExtensionDiscountExist(motorExtensionDiscount) {
    var state = false;
    app.vm.info.motorExtensionDiscounts.forEach(function (value, index) {
        if (motorExtensionDiscount.id == ''
            && motorExtensionDiscount.policyNumber.toLowerCase() == value.policyNumber.toLowerCase()
            && motorExtensionDiscount.description.toLowerCase() == value.description.toLowerCase()) {
            state = true;
        }
    });
    return state;
}

//adds contact person to contactPerson Array after checking for duplicates or update request
function populateCoInsurance(obj) {
    var motorCoInsurance = JSON.parse(JSON.stringify(obj));

    if (motorCoInsuranceExist(motorCoInsurance)) {
        return;
    }
    else if (motorCoInsurance.id != '') {
        app.vm.info.motorCoInsurances.forEach(function (value, index) {
            if (motorCoInsurance.id == value.id) {
                value = motorCoInsurance;
            }
        });
    }
    else {
        motorCoInsurance.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.motorCoInsurances.push(motorCoInsurance);
    }
}

//checks to see if contact person already exist
function motorCoInsuranceExist(motorCoInsurance) {
    var state = false;
    app.vm.info.motorCoInsurances.forEach(function (value, index) {
        if (motorCoInsurance.id == ''
            && motorCoInsurance.participant.toLowerCase() == value.participant.toLowerCase()) {
            state = true;
        }
    });
    return state;
}