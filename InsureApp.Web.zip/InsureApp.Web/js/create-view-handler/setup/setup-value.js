﻿function info(id, setUpNameId, name, parentId) {
    this.id = id;
    this.setUpNameId = setUpNameId;
    this.name = name;
    this.parentId = parentId;
}
function setUpName(id, name, parentId) {
    this.id = id;
    this.name = name;
    this.parentId = parentId;
}
function dropDownData(id, name) {
    this.id = id;
    this.name = name;
}

var infoViewModel = {
    info: new info(0, 0, null, 0),
    setUpNames: [],
    parents: [],
    toggleParentValidation: false
}

//function getDropDownParentData(url, viewModel, parentId) {
//    $.ajax({
//        url: url,
//        contentType: "application/json",
//        type: "GET",
//        data: { 'parentId': parentId },
//        success: function (data) {
//            var parentData = data.parentData;
//            if (parentData.length > 0) {
//                viewModel.toggleParentValidation = true;
//            }
//            viewModel.parents = [];
//            parentData.forEach(function (value) {
//                viewModel.parents.push(new dropDownData(value.id, value.name));
//            });
//        }
//    });
//}

function validate() {
    $('#form').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            setUpNameId: {
                validators: {
                    notEmpty: {
                        message: '<strong>Setup Name</strong> Required'
                    }
                }
            },
            name: {
                validators: {
                    notEmpty: {
                        message: '<strong>Name</strong> Required'
                    }
                }
            },
        //    parent: {
        //        validators: {
        //            notEmpty: {
        //                message: '<strong>Parent</strong> Required'
        //            }
        //        }
        //    }
        },
        onSuccess: function (e) {
            e.preventDefault()
            submitFn.saveData(new info(0, app.vm.info.setUpNameId, null, 0), "MiscSetUpValue/Create");
            MVCGrid.reloadGrid("MiscSetUpValue");
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

function loadModal(setUpNameId, parentId, urlStructure, urlData, isNew) {

    submitFn.callModal('myModal');

    $.ajax({
        url: urlStructure,
        dataType: "html",
        beforeSend: function () {
            $('div#create-form').empty();
            $('div#create-form').html('<img id="loader-img" alt="" src="img/ajax_loader2.gif" width="100" height="100" style="position: absolute; right: 46%; top: 1000%;" />');
        },
        success: function (data) {
            $('div#create-form').html(data);
        },
        complete: function () {

            if (isNew) {
                infoViewModel.info = new info(0, setUpNameId, null, 0)
            }
            else {
                infoViewModel.info = new GetDataFromServer().loadData(urlData, null, 'setUpValue', true);
            }

            app = new Vue({
                el: "#create-form",
                data: {
                    loading: false,
                    vm: infoViewModel
                }
            })

            new GetDropDownData().load('/MiscSetUpValue/GetParent', app.vm, { 'parentId': parentId }, 'parents', 'parentData', false);
            //toggle validation for the parent drop down if there are items in it
            if (infoViewModel.parents > 0) {
                app.vm.toggleParentValidation = true;
            }

            validate();
            new GetDropDownData().load('/MiscSetUpValue/Get', app.vm, null, 'setUpNames', 'setUpNames', true);
        }
    });
}

$('#loadForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var setUpNameId = $(this).attr('data-SetUpNameId');
    var parentId = $(this).attr('data-ParentId');
    loadModal(setUpNameId, parentId, url, null, true);

})

$('#backToSetUpName').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var ajaxCall = new MyAjaxCall();
    ajaxCall.load(url, 'div#mainDisplay', null, true);
});

function editRow(sender) {
    var url = $(sender).attr('data-UrlStructure');
    var urlStructure = url;
    var urlData = $(sender).attr('data-urlData');
    var parentId = $(this).attr('data-parentId');
    loadModal(0, parentId, urlStructure, urlData, false);
    return false;
}

function loadStructureValue(sender) {
    var url = $(sender).attr('href');
    var ajaxCall = new MyAjaxCall();
    ajaxCall.load(url, 'div#mainDisplay', null, true);
    return false;
}
