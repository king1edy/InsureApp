﻿function info(id, name) {
    this.id = id;
    this.name = name;
    this.parentId = 0;
}

var infoViewModel = {
    info: new info(0, null, 0),
    infos: []
}

function getDropDownData(url) {
    $.ajax({
        url: url,
        contentType: "application/json",
        type: "GET",
        success: function (data) {
            infoViewModel.infos = [];
            data.forEach(function(value){
                infoViewModel.infos.push(new info(value.id, value.name));
            });
        }
    });
}

function validate() {
    $('#form').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: '<strong>Name</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault()
            submitFn.saveData(new info(0, null, 0), "MiscSetupName/Create")
            //submitFn.clearFields('form');
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

function loadModal(urlStructure, urlData, isNew) {
    
    submitFn.callModal('myModal');

    $.ajax({
        url: urlStructure,
        dataType: "html",
        beforeSend: function () {
            $('div#create-form').empty();
            $('div#create-form').html('<img id="loader-img" alt="" src="img/ajax_loader2.gif" width="100" height="100" style="position: absolute; right: 46%; top: 1000%;" />');
        },
        success: function (data) {
            $('div#create-form').html(data);            
        },
        complete: function () {

            if (isNew) {
                infoViewModel.info = new info(0,null,0)
            }
            else {
                infoViewModel.info = new GetDataFromServer().loadData(urlData, null, 'setUpName', true);
            }
            app = new Vue({
                el: "#create-form",
                data: {
                    loading: false,
                    vm: infoViewModel
                }
            })
            validate();
            new GetDropDownData().load('/MiscSetupName/Get', app.vm, null, 'infos', 'setupNames', true);
        }
    });
}
 
$('#loadForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    loadModal(url, null, true);
})

function editRow(sender) {
    var url = $(sender).attr('data-UrlStructure');
    var urlStructure = url;
    var urlData = $(sender).attr('data-urlData');
    loadModal(urlStructure, urlData, false);
    return false;
}

function loadSetUpValue(sender) {
    var url = $(sender).attr('href'); 
    var setUpNameId = $(sender).attr('data-setupnameId');
    var parentId = $(sender).attr('data-parentId');

    var data = {
                parentId: parseInt(parentId),
                nameId: parseInt(setUpNameId)
    }

    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', data, true);

    return false;
}
 