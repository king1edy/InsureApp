﻿function info(bond) {
    this.id = bond != null ? bond.id : '';
    this.contract = bond != null ? bond.contract : '';
    this.customerId = bond != null ? bond.customerId : '';
    this.effectiveDate = bond != null ? bond.effectiveDate : '';
    this.policyNumber = bond != null ? bond.policyNumber : '';
    this.situationOfRisk = bond != null ? bond.situationOfRisk : '';
    this.businessType = bond != null ? bond.businessType : '';
    this.businessOccupation = bond != null ? bond.businessOccupation : '';
    this.itemNumber = bond != null ? bond.itemNumber : '';
    this.additionalInsured = bond != null ? bond.additionalInsured : '';
    this.excess = bond != null ? bond.excess : '';
    this.employeeName = bond != null ? bond.employerName : '';
    this.employeeAddress = bond != null ? bond.employerAddress : '';
    this.contractorsName = bond != null ? bond.contractorName : '';
    this.contractorsAddress = bond != null ? bond.contractorAddress : '';
    this.inspectionDate = bond != null ? bond.inspectionDate : '';
    this.sumInsured = bond != null ? bond.sumInsured : '';
    this.premiumOrRate = bond != null ? bond.premiumOrRate : '';
    this.prorataDays = bond != null ? bond.prorataDays : '';
    this.proratePremium = bond != null ? bond.proratePremium : '';
    this.lastClaimDate = bond != null ? bond.lastClaimDate : '';
    this.riskProfile = bond != null ? bond.riskProfile : '';

    this.coInsurances = bond != null ? bond.coInsurances : [];
    this.extensionDiscounts = bond != null ? bond.extensionDiscounts : [];
}


var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    businessTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'business type', 'parentId': null }, 'setUpValues', false),
    businessOccupations: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'business occupation', 'parentId': null }, 'setUpValues', false),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    extensionTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'extension types', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'policy type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'insurance companies', 'parentId': null }, 'setUpValues', false)
}


$(function () {
    var bondId = $('#hdBond').val();
    var customerId = $('#hdCustomer').val();

    //for a new Agent Registration
    if (bondId == 0) {
        infoViewModel.info = new info(null);
    }

        //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Bond/EditData/',
            contentType: "application/json",
            type: "GET",
            data: {id: bondId},
            success: function (data) {
                infoViewModel.info = data;
            }
        });
    }

    //infoViewModel.info.customerId = customerId;

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal');
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal');
            }
        }
    })

    validate();
});

function validate() {

    $form = $('#bond').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            contract: {
                validators: {
                    notEmpty: {
                        message: 'Contract field is required'
                    }
                }
            },
            effectiveDate: {
                validators: {
                    notEmpty: {
                        message: 'Effective date  is required'
                    }
                }
            },
            policyNumber: {
                validators: {
                    notEmpty: {
                        message: 'Policy Number  is required'
                    }
                }
            },
            risk: {
                validators: {
                    notEmpty: {
                        message: 'Risk field is required'
                    }
                }
            },
            probableLoss: {
                validators: {
                    notEmpty: {
                        message: 'Maximum probable Loss is required'
                    }
                }
            },
            businessType: {
                validators: {
                    notEmpty: {
                        message: 'Business type  is required'
                    }
                }
            },
            businessOccupation: {
                validators: {
                    notEmpty: {
                        message: 'Business occupation is required'
                    }
                }
            },
            itemNumber: {
                validators: {
                    notEmpty: {
                        message: 'Item number is required'
                    }
                }

            },
            effectiveDate: {
                validators: {
                    notEmpty: {
                        message: 'Effective date is required'
                    }
                }
            },
            employerName: {
                validators: {
                    notEmpty: {
                        message: 'Employer name is required'
                    }
                }
            },
            employerAddress: {
                validators: {
                    notEmpty: {
                        message: 'Employer address is required'
                    }
                }
            },
            contractorName: {
                validators: {
                    notEmpty: {
                        message: 'Contractor name is required'
                    }
                }
            },
            contractorAddress: {
                validators: {
                    notEmpty: {
                        message: 'Contractor address is required'
                    }
                }
            },
            inspectionDate: {
                validators: {
                    notEmpty: {
                        message: 'Inspection date is required'
                    }
                }
            },
            additionalInsured: {
                validators: {
                    notEmpty: {
                        message: 'Additional insured is required'
                    }
                }
            },
            excess: {
                validators: {
                    notEmpty: {
                        message: 'Excess is required'
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                        message: 'Sum insured is required'
                    }
                }
            },
            premiumOrRate: {
                validators: {
                    notEmpty: {
                        message: 'Premium Or Rate is required'
                    }
                }
            },
            prorataDays: {
                validators: {
                    notEmpty: {
                        message: 'Prorate days is required'
                    }
                }
            },
            proratePremium: {
                validators: {
                    notEmpty: {
                        message: 'Prorate premium is required'
                    }
                }
            },
            lastClaimDate: {
                validators: {
                    notEmpty: {
                        message: 'Last claim date is required'
                    }
                }
            },
            riskProfile: {
                // The group will be set as default (.form-group)
                validators: {
                    notEmpty: {
                        message: 'Risk profile is required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'Bond/Create');
            submitFn.clearFields('bond');
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.coInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.coInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            type: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentage: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.extensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.extensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}
