﻿function info(privateCustomer) {
    this.id = privateCustomer != null ? privateCustomer.id : '';
    this.firstName = privateCustomer != null ? privateCustomer.firstName : '';
    this.lastName = privateCustomer != null ?  privateCustomer.lastName : '';
    this.title = privateCustomer != null ? privateCustomer.title : '';
    this.gender = privateCustomer != null ? privateCustomer.gender : '';
    this.maritalStatus = privateCustomer != null ? privateCustomer.maritalStatus : '';
    this.dob = privateCustomer != null ? privateCustomer.dob : '';
    this.religion = privateCustomer != null ? privateCustomer.religion : '';
    this.nationality = privateCustomer != null ? privateCustomer.Nationality : '';
    this.stateProvince = privateCustomer != null ? privateCustomer.stateProvince : '';
    this.streetName = privateCustomer != null ? privateCustomer.streetName : '';
    this.buildingNumber = privateCustomer != null ? privateCustomer.buildingNumber : '';
    this.pmb = privateCustomer != null ? privateCustomer.pmb : '';
    this.phone = privateCustomer != null ? privateCustomer.phone : '';
    this.email = privateCustomer != null ? privateCustomer.email : '';
}

var infoViewModel = {
    info: new info(null),
    maritalStatuses: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'marital status', 'parentId': null }, 'setUpValues', true),
    titles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'title', 'parentId': null }, 'setUpValues', true),
    religions: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'religion', 'parentId': null }, 'setUpValues', true),
    nationalities: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'country', 'parentId': null }, 'setUpValues', false),
    states: []
}
    /*
     Bootstrap Form Validator
     */
function validate() {
    //TODO: Validation of the main form
    $('#form').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            title: {
                validators: {
                    notEmpty: {
                        message: '<strong>Title</strong> Required'
                    }
                }
            },
            firstName: {
                validators: {
                    notEmpty: {
                        message: '<strong>First Name</strong> Required'
                    }
                }
            },
            lastName: {
                validators: {
                    notEmpty: {
                        message: '<strong>Last Name</strong> Required'
                    }
                }
            },
            gender: {
                validators: {
                    notEmpty: {
                        message: '<strong>Gender</strong> Required'
                    }
                }
            },
            maritalStatus: {
                validators: {
                    notEmpty: {
                        message: '<strong>Marital Status</strong> Required'
                    }
                }
            },
            //dob: {
            //    validators: {
            //        notEmpty: {
            //            message: '<strong>D.O.B</strong> Required'
            //        },
            //        date: {
            //            format: 'MM/dd/yyyy',
            //            message: '<strong>Invalid Date</strong>'
            //        }
            //    }
            //},
            religion: {
                validators: {
                    notEmpty: {
                        message: '<strong>Religion</strong> Required'
                    }
                }
            },
            nationality: {
                validators: {
                    notEmpty: {
                        message: '<strong>Nationality</strong> Required'
                    }
                }
            },
            state: {
                validators: {
                    notEmpty: {
                        message: '<strong>State/Province</strong> Required'
                    }
                }
            },
            streetName: {
                validators: {
                    notEmpty: {
                        message: '<strong>Street Number</strong> Required'
                    }
                }
            },
            buildingNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Building Number</strong> Required'
                    }
                }
            },
            pmb: {
                validators: {
                    notEmpty: {
                        message: '<strong>PO. Box/PMB</strong> Required'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: '<strong>Email</strong> Required'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: '<strong>Phone Number</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault()
            submitFn.saveData(new info(null),'PrivateCustomer/Create');
            submitFn.clearFields('form')
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

function loadModal(urlStructure, urlData, isNew) {

    submitFn.callModal('myModal');

    $.ajax({
        url: urlStructure,
        dataType: "html",
        beforeSend: function () {
            $('div#create-form').empty();
            $('div#create-form').html('<img id="loader-img" alt="" src="img/ajax_loader2.gif" width="100" height="100" style="position: absolute; right: 46%; top: 1000%;" />');
        },
        success: function (data) {
            $('div#create-form').html(data);
        },
        complete: function () {

            if (isNew) {
                infoViewModel.info = new info(null);
            }
            else {
                $.ajax({
                    url: urlData,
                    contentType: "application/json",
                    type: "GET",
                    success: function (data) {
                        new GetDropDownData().load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': data.nationality }, 'states', 'setUpValues', false);
                        infoViewModel.info = data;
                    }
                });
            }
            app = new Vue({
                el: "#create-form",
                data: {
                    loading: false,
                    vm: infoViewModel
                },
                methods: {
                    loadStates: function () {
                        new GetDropDownData().load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': app.vm.info.nationality }, 'states', 'setUpValues', true);
                    }
                }
            })

            validate();
        }
    });
}

$('#loadForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    loadModal(url, null, true);
})

function editRow(sender) {
    var url = $(sender).attr('data-UrlStructure');
    var urlStructure = url;
    var urlData = $(sender).attr('data-urlData');
    var parentId = $(this).attr('data-parentId');
    initializeViewModel();
    loadModal(urlStructure, urlData, false);
    return false;
}
