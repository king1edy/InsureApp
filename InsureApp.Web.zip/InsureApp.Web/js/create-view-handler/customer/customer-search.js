﻿function info(obj) {
    this.id = obj != null ? obj.id : '';
    this.firstName = obj != null ? obj.firstName : '';
    this.lastName = obj != null ? obj.lastName : '';
    this.email = obj != null ? obj.email : '';
    this.phone = obj != null ? obj.phone : '';
    this.dob = obj != null ? obj.dob : '';
    this.gender = obj != null ? obj.gender : "";
}

var infoViewModel = {
    info: new info(null)
}

var customerType = null;

function toggleCustomerType(obj) {
    customerType = {
        CustomerType: $(obj).val()
    };
    toggleGrid(customerType.CustomerType);
};


function toggleGrid(type) {
    var privateJSON = {
        'CustomerId': true,
        'customerType': 'Private',
        'FirstName': true,
        'LastName': true,
        'Gender': true
    }
    var corporateJSON = {
        'CustomerId': true,
        'customerType': 'Corporate',
        'Company Name': true,
        'Registration Number': true,
        'Year Incorporated': true,
        'Nature Of Business': true
    }
    MVCGrid.setColumnVisibility('AllCustomerGrid', type == 'Private' ? privateJSON : corporateJSON);
}

$(window).on('load', function (e) {
    toggleGrid('Private');
})

function loadConfirmation (sender) {
    var url = $(sender).attr('data-url');
    var customerId = $(sender).attr('data-customer-id');
    var custId = $(sender).attr('data-cust-id');
    loadModal(url, { customerId: customerId, custId: custId });
}

function loadModal(url, data) {

    submitFn.callModal('myModal');

    $.ajax({
        url: url,
        dataType: "html",
        data:  data,
        beforeSend: function () {
            $('div#confirm-form').empty();
            $('div#confirm-form').html('<img id="loader-img" alt="" src="img/ajax_loader2.gif" width="100" height="100" style="position: absolute; right: 46%; top: 1000%;" />');
        },
        success: function (data) {
            $('div#confirm-form').html(data);
        },
        complete : function () {
            infoViewModel.info = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', data, 'customerData', false)

            app = new Vue({
                el: "#create-form",
                data: {
                    loading: false,
                    vm: infoViewModel,
                    modalEventSource : null
                }
            })
        }
    });
}


//call when new policy page is opening for fresh customer subscription
function loadCreate(sender) {
    var custId = $('#hdCustomer').val();
    var formType = $('#hdFormType').val();
    var policyType = $('#hdPolicyType').val();
    var path = formType == "single" ? "create" : "createMultiple";
    var url = policyType + "/" + path;
    var ajaxCall = new MyAjaxCall
    ajaxCall.load(url, 'div#mainDisplay', { custId: custId });
    return false;
}

function describeEvent() {
    app.modalEventSource = "confirm-button";
}

$('#myModal').on('hidden.bs.modal', function (e) {
    if (app.modalEventSource) {
        var btn = $('#myModal .modal-dialog .modal-content .modal-footer button.btn');
        loadCreate(btn);
    }
    
})