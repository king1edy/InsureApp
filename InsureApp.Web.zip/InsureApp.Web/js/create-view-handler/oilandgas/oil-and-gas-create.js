﻿function info(oilAndGas) {
    this.id = oilAndGas != null ? oilAndGas.id : '';
    this.customerId = oilAndGas != null ? oilAndGas.customerId : 27;
    this.insuredInterest = oilAndGas != null ? oilAndGas.insuredInterest : '';
    this.geographicalLimit = oilAndGas != null ? oilAndGas.geographicalLimit : '';
    this.businessType = oilAndGas != null ? oilAndGas.businessType : '';
    this.situationOfRisk = oilAndGas != null ? oilAndGas.situationOfRisk : '';
    this.statusOfWell = oilAndGas != null ? oilAndGas.statusOfWell : '';
    this.inspectionDate = oilAndGas != null ? oilAndGas.inspectionDate : '';
    this.excessDeductibles = oilAndGas != null ? oilAndGas.excessDeductibles : '';
    this.sumInsured = oilAndGas != null ? oilAndGas.sumInsured : '';
    this.premiumOrRate = oilAndGas != null ? oilAndGas.premiumOrRate : '';
    this.prorataDays = oilAndGas != null ? oilAndGas.prorataDays : '';
    this.proratePremium = oilAndGas != null ? oilAndGas.proratePremium : '';
    this.lastClaimDate = oilAndGas != null ? oilAndGas.lastClaimDate : '';
    this.riskProfile = oilAndGas != null ? oilAndGas.riskProfile : '';
    
    this.coInsurances = oilAndGas != null ? oilAndGas.coInsurances : [];
    this.extensionDiscounts = oilAndGas != null ? oilAndGas.extensionDiscounts : [];
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    businessTypes: new GetDataFromServer().loadData('/MiscSetUpValue/GetSetUpValues', { 'setUpName': 'business type', 'parentId': null }, 'setUpValues', false),
    statusOfWells: new GetDataFromServer().loadData('/MiscSetUpValue/GetSetUpValues', { 'setUpName': 'status', 'parentId': null }, 'setUpValues', false),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    types: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'extension types', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'policy type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'insurance companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    var custId = $('#hdCustomer').val();
    var oilAndGasId = $('#hdOilAndGas').val();
    
    infoViewModel.customer = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', { custId: custId }, 'customerData', false);

    //for a new Agent Registration
    if (oilAndGasId == 0) {
        infoViewModel.info = new info(null);
    }

    //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'GasAndOil/EditData/' + oilAndGasId,
            contentType: "application/json",
            type: "GET",
            success: function (data) {
            infoViewModel.info = data;
        }
        });
    }
    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        }
    })

    validate();
});
   
function validate() {
    $('#form').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            insuredInterest: {
                validators: {
                    notEmpty: {
                        message: '<strong>Insured Interest</strong> required'
                    }
                }
            },
            geographicalLimit: {
                validators: {
                    notEmpty: {
                        message: '<strong>Geographical Limit</strong> required'
                    }
                }
            },
            businessType: {
                validators: {
                    notEmpty: {
                        message: '<strong>Business Type</strong> required'
                    }
                }
            },
            situationOfRisk: {
                validators: {
                    notEmpty: {
                        message: '<strong>Situation of Risk</strong> required'
                    },
                    stringLength: {
                        max: 50,
                        message: '<strong>Situation of Risk</strong> must be less than 50 characters long'
                    }
                }
            },
            statusOfWell: {
                validators: {
                    notEmpty: {
                        message: '<strong>Status of Well</strong> required'
                    }
                }
            },
            inspectionDate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Inspection Date</strong> required'
                    }
                }
            },
            excessDeductibles: {
                validators: {
                    notEmpty: {
                        message: '<strong>Excess Deductibles</strong> required'
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                        message: '<strong>Sum Insured</strong> required'
                    }
                }
            },
            premiumOrRate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Premium or Rate</strong> required'
                    }
                }
            },
            prorataDays: {
                validators: {
                    notEmpty: {
                        message: '<strong>Prorata Days</strong> required'
                    }
                }
            },
            proratePremium: {
                validators: {
                    notEmpty: {
                        message: '<strong>Prorate Premium</strong> required'
                    }
                }
            },
            lastClaimDate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Last Claim Date</strong> required'
                    },
                }
            },
            riskProfile: {
                validators: {
                    notEmpty: {
                        message: '<strong>Risk Profile</strong> Required'
                    }
                }
            },
            EntryDate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Last Claim Date</strong> required'
                    }
                }
            },
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'GasAndOil/Create');
            submitFn.clearFields('form')
       
        },
        onError: function (e) {
            e.preventDefault();
        }
    });

}