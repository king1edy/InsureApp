﻿function info(id, name) {
    this.id = id;
    this.name = name;
    this.parentId = 0;
}

var infoViewModel = {
    info: new info(0, null, 0),
    infos: []
}

function validate() {
    $('#form').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: '<strong>Name</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault()
            submitFn.saveData(new info(0, null, 0), "OrgStructureName/Create")
            MVCGrid.reloadGrid("OrgStructureName");
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

function loadModal(urlStructure, urlData, isNew) {
    
    submitFn.callModal('myModal');

    $.ajax({
        url: urlStructure,
        dataType: "html",
        beforeSend: function () {
            $('div#create-form').empty();
            $('div#create-form').html('<img id="loader-img" alt="" src="img/ajax_loader2.gif" width="100" height="100" style="position: absolute; right: 46%; top: 1000%;" />');
        },
        success: function (data) {
            $('div#create-form').html(data);            
        },
        complete: function () {

            if (isNew) {
                infoViewModel.info = new info(0,null,0)
            }
            else {
                $.ajax({
                    url: urlData,
                    contentType: "application/json",
                    type: "GET",
                    success: function (data) {
                        infoViewModel.info = data;
                    }
                });
            }
            app = new Vue({
                el: "#create-form",
                data: {
                    loading: false,
                    vm: infoViewModel
                }
            })

            validate();
            new GetDropDownData().load('/OrgStructureName/Get', app.vm, null, 'infos', 'setupNames', true);
        }
    });
}
 
$('#loadForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    loadModal(url, null, true); 
})

function editRow(sender) {
    var url = $(sender).attr('data-UrlStructure');
    var urlStructure = url;
    var urlData = $(sender).attr('data-urlData');
    loadModal(urlStructure, urlData, false);
    return false;
}

function loadStructureValue(sender) {
    var url = $(sender).attr('href'); 
    var orgstructurenameId = $(sender).attr('data-orgstructurenameId');
    var parentId = $(sender).attr('data-parentId');

    var data = {
        parentId: parseInt(parentId),
        nameId: parseInt(orgstructurenameId)
    }

    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', data, true);

    return false;
}
 