﻿function info(id, OrgStructureNameId, name, parentId) {
    this.id = id;
    this.OrgStructureNameId = OrgStructureNameId;
    this.name = name;
    this.parentId = parentId;
}
function structureName(id, name, parentId) {
    this.id = id;
    this.name = name;
    this.parentId = parentId;
}

var infoViewModel = {
    info: new info(0, 0, null, 0),
    structureNames: [],
    parents: [],
    toggleParentValidation: false
}

function validate() {
    $('#form').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            setUpNameId: {
                validators: {
                    notEmpty: {
                        message: '<strong>Setup Name</strong> Required'
                    }
                }
            },
            name: {
                validators: {
                    notEmpty: {
                        message: '<strong>Name</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault()
            submitFn.saveData(new info(0, app.vm.info.OrgStructureNameId, null, 0), "OrgStructureValue/Create");
            MVCGrid.reloadGrid("OrgStructureValue");
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

function loadModal(orgStructureNameId, parentId, urlStructure, urlData, isNew) {
    
    submitFn.callModal('myModal');

    $.ajax({
        url: urlStructure,
        dataType: "html",
        beforeSend: function () {
            $('div#create-form').empty();
            $('div#create-form').html('<img id="loader-img" alt="" src="img/ajax_loader2.gif" width="100" height="100" style="position: absolute; right: 46%; top: 1000%;" />');
        },
        success: function (data) {
            $('div#create-form').html(data);            
        },
        complete: function () {

            if (isNew) {
                infoViewModel.info = new info(0, orgStructureNameId, null, 0)
            }
            else {
                infoViewModel.info = new GetDataFromServer().loadData(urlData, null, 'structureValue', true);
            }

            app = new Vue({
                el: "#create-form",
                data: {
                    loading: false,
                    vm: infoViewModel
                }
            })
            
            new GetDropDownData().load('/OrgStructureValue/GetParent', app.vm, { 'parentId': parentId }, 'parents', 'parentData', true);
            //toggle validation for the parent drop down if there are items in it
            if (infoViewModel.parents > 0) {
                app.vm.toggleParentValidation = true;
            }
          
            validate();
            new GetDropDownData().load('/OrgStructureValue/Get', app.vm, null, 'structureNames', 'structureNames', true);
        }
    });
}
 
$('#loadForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var orgStructureNameId = $(this).attr('data-OrgStructureNameId');
    var parentId = $(this).attr('data-ParentId');
    loadModal(orgStructureNameId, parentId, url, null, true);  
})

$('#backToStructureName').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var ajaxCall = new MyAjaxCall();
    ajaxCall.load(url, 'div#mainDisplay', null, true);
});

function editRow(sender) {
    var url = $(sender).attr('data-UrlStructure');
    var urlStructure = url;
    var urlData = $(sender).attr('data-urlData');
    var parentId = $(this).attr('data-parentId');
    loadModal(0, parentId, urlStructure, urlData, false);
    return false;
}

function loadStructureValue(sender) {
    var url = $(sender).attr('href');
    var ajaxCall = new MyAjaxCall();
    ajaxCall.load(url, 'div#mainDisplay', null, true);
    return false;
}
