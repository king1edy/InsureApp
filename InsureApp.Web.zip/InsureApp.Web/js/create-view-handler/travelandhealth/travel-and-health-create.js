﻿function info(travelAndHealth) {
    this.id = travelAndHealth != null ? travelAndHealth.id : '';
    this.customerId = travelAndHealth != null ? travelAndHealth.customerId : 27;
    this.itemNumber = travelAndHealth != null ? travelAndHealth.itemNumber : '';
    this.travelCertificate = travelAndHealth != null ? travelAndHealth.travelCertificate : '';
    this.passportNumber = travelAndHealth != null ? travelAndHealth.passportNumber : '';
    this.numberOfTravellers = travelAndHealth != null ? travelAndHealth.numberOfTravellers : '';
    this.nextOfKin = travelAndHealth != null ? travelAndHealth.nextOfKin : '';
    this.nextOfKinAddress = travelAndHealth != null ? travelAndHealth.nextOfKinAddress : '';
    this.nextOfKinTelephoneNo = travelAndHealth != null ? travelAndHealth.nextOfKinTelephoneNo : '';
    this.destination = travelAndHealth != null ? travelAndHealth.destination : '';
    this.travellingDate = travelAndHealth != null ? travelAndHealth.travellingDate : '';
    this.returningDate = travelAndHealth != null ? travelAndHealth.returningDate : '';
    this.businessOccupation = travelAndHealth != null ? travelAndHealth.businessOccupation : '';
    this.excess = travelAndHealth != null ? travelAndHealth.excess : '';
    this.sumInsured = travelAndHealth != null ? travelAndHealth.sumInsured : '';
    this.premiumOrRate = travelAndHealth != null ? travelAndHealth.premiumOrRate : '';
    this.prorataDays = travelAndHealth != null ? travelAndHealth.prorataDays : '';
    this.proratePremium = travelAndHealth != null ? travelAndHealth.proratePremium : '';
    this.lastClaimDate = travelAndHealth != null ? travelAndHealth.lastClaimDate : '';
    this.riskProfile = travelAndHealth != null ? travelAndHealth.riskProfile : '';
    this.policyNumber = travelAndHealth != null ? travelAndHealth.policyNumber : '';

    this.coInsurances = travelAndHealth != null ? travelAndHealth.coInsurances : [];
    this.extensionDiscounts = travelAndHealth != null ? travelAndHealth.extensionDiscounts : [];
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    destinations: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'destination', 'parentId': null }, 'setUpValues', false),
    businessOccupations: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'business occupation', 'parentId': null }, 'setUpValues', false),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    types: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'extension types', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'policy type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'insurance companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    var travelAndHealthId = $('#hdTravelAndHealth').val();
    var custId = $('#hdCustomer').val();
    console.log('Travel And Health Id: ' + travelAndHealthId);

    var custId = $('#hdCustomer').val();

    infoViewModel.customer = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', { custId: custId }, 'customerData', false);

    //for a new Agent Registration
    if (travelAndHealthId == 0) {
        infoViewModel.info = new info(null);
    }

    //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'TravelAndHealth/EditData/' + travelAndHealthId,
            contentType: "application/json",
            type: "GET",
            success: function (data) {
                infoViewModel.info = data;
            }
        });
    }
    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal');
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal');
            }
        }
    })

    validate();
});

function validate() {
    $form = $('#travelAndHealth').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
    fields: {
        travelCertificate: {
            validators: {
                notEmpty: {
                    message: '<strong>Travel Certificate</strong> required'
                }
            }
        },
        passportNumber: {
            validators: {
                notEmpty: {
                    message: '<strong>Passport Number</strong> required'
                }
            }
        },
        numberOfTravellers: {
            validators: {
                notEmpty: {
                    message: '<strong>Number of Travellers</strong> required'
                }
            }
        },
        nextOfKin: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin</strong> required'
                }
            }
        },
        nextOfKinAddress: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin Address </strong> required'
                }
            }
        },
        nextOfKinTelephone: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin Telephone </strong> required'
                }
            }
        },
        destination: {
            validators: {
                notEmpty: {
                    message: '<strong>Destination </strong>required'
                }
            }
        },
        travellingDate: {
            validators: {
                notEmpty: {
                    message: '<strong>Travelling Date </strong> required'
                }
            }

        },
        returningDate: {
            validators: {
                notEmpty: {
                    message: '<strong>Returning Date </strong> required'
                }
            }
        },
        businessOccupation: {
            validators: {
                notEmpty: {
                    message: '<strong>Business Occupation</strong> required'
                }
            }
        },
        itemNumber: {
            validators: {
                notEmpty: {
                    message: '<strong>Next of Kin</strong> required'
                }
            }
        },
        excess: {
            validators: {
                notEmpty: {
                    message: '<strong>Excess </strong> required'
                }
            }
        },
        sumInsured: {
            validators: {
                notEmpty: {
                    message: '<strong>Sum Insured</strong> required'
                }
            }
        },
        premiumOrRate: {
            validators: {
                notEmpty: {
                    message: '<strong>Premium or Rate </strong> required'
                }
            }
        },
        prorataDays: {
            validators: {
                notEmpty: {
                    message: '<strong>Prorata Days </strong> required'
                }
            }
        },
        proratePremium: {
            validators: {
                notEmpty: {
                    message: '<strong>Prorate Premium </strong> required'
                }
            }
        },
        lastClaimDate: {
            validators: {
                notEmpty: {
                    message: '<strong>Last Claim Date </strong> required'
                }
            }
        },
        riskProfile: {
            validators: {
                notEmpty: {
                    message: '<strong>Risk profile field </strong> required'
                }
            }
        }
    },
      policyNumber: {
         validators: {
             notEmpty: {
                message: '<strong>Policy Number </strong> required'
            }
        }
    },
    onSuccess: function (e) {
        e.preventDefault();
        submitFn.saveData(new info(null), 'TravelAndHealth/Create');
        submitFn.clearFields('travelAndHealth');
    },
    onError: function (e) {
    e.preventDefault();
        }
    })

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.coInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.coInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            type: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentage: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.extensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.extensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

function coInsuranceDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.coInsurances.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.coInsurances.splice(arrayIndex, 1);
        }
    });
}

function coInsuranceEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.coInsurances.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.coInsurance = value;
        }
    });
    $('#' + 'coInsuranceModal').modal();
}

function extensionDiscountDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.extensionDiscounts.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.extensionDiscounts.splice(arrayIndex, 1);
        }
    });
}

function extensionDiscountEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.extensionDiscounts.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.extensionDiscount = value;
        }
    });
    $('#' + 'extensionDiscountModal').modal();
}


//returns screen to the grid display of corporate customers
$('#btnBackToAgent').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', null);
    myAjaxCall();
});

//adds Extension Discount to extensionDiscount Array after checking for duplicates or update request
function populateExtensionDiscounts(obj) {
    var extensionDiscount = JSON.parse(JSON.stringify(obj));
    
    if (extensionDiscountExist(extensionDiscount)) {
        return;
    }
    else if (extensionDiscount.id != '') {
        app.vm.info.extensionDiscounts.forEach(function (value, index) {
            if (extensionDiscount.id == value.id) {
                value = extensionDiscount;
            }
        });
    }
    else {
        extensionDiscount.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.extensionDiscounts.push(extensionDiscount);
    }
}

//checks to see if contact person already exist
function extensionDiscountExist(extensionDiscount) {
    var state = false;
    app.vm.info.extensionDiscounts.forEach(function (value, index) {
        if (extensionDiscount.id == ''
            && extensionDiscount.policyNumber.toLowerCase() == value.policyNumber.toLowerCase()
            && extensionDiscount.description.toLowerCase() == value.description.toLowerCase()) {
            state = true;
        }
    });
    return state;
}

//adds contact person to contactPerson Array after checking for duplicates or update request
function populateCoInsurance(obj) {
    var coInsurance = JSON.parse(JSON.stringify(obj));

    if (coInsuranceExist(coInsurance)) {
        return;
    }
    else if (coInsurance.id != '') {
        app.vm.info.coInsurances.forEach(function (value, index) {
            if (coInsurance.id == value.id) {
                value = coInsurance;
            }
        });
    }
    else {
        coInsurance.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.coInsurances.push(coInsurance);
    }
}

//checks to see if contact person already exist
function coInsuranceExist(coInsurance) {
    var state = false;
    app.vm.info.coInsurances.forEach(function (value, index) {
        if (coInsurance.id == ''
            && coInsurance.participant.toLowerCase() == value.participant.toLowerCase()) {
            state = true;
        }
    });
    return state;
}