﻿//loads search page for subscription
$('#loadSearchForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', null, true);
})

$('#loadForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', { fireId: 0 });
})

function editRow(sender) {
    var url = $(sender).attr('data-UrlStructure');
    var urlStructure = url;
    var dataId = $(sender).attr('data-id');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', { fireId: dataId });
}