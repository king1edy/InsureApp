﻿function info(aviation) {
    this.id = aviation != null ? aviation.id : '';
    this.customerId = aviation != null ? aviation.customerId : '';
    this.insuredInterest = aviation != null ? aviation.insuredInterest : '';
    this.voyageFrom = aviation != null ? aviation.voyageFrom : '';
    this.voyageTo = aviation != null ? aviation.voyageTo : '';
    this.clauses = aviation != null ? aviation.clauses : '';
    this.exclusions = aviation != null ? aviation.exclusions : '';
    this.yearOfManufacture = aviation != null ? aviation.yearOfManufacture : '';
    this.placeOfManufacture = aviation != null ? aviation.placeOfManufacture : '';
    this.numberOfCrew = aviation != null ? aviation.numberOfCrew : '';
    this.riskProfile = aviation != null ? aviation.riskProfile : '';
    this.priceOfAirCraft = aviation != null ? aviation.priceOfAirCraft : '';
    this.pilotDetails = aviation != null ? aviation.pilotDetails : '';
    this.totalDeclarationValueForInsurancePurpose = aviation != null ? aviation.totalDeclarationValueForInsurancePurpose : '';
    this.survey = aviation != null ? aviation.survey : '';
    this.fuel = aviation != null ? aviation.fuel : '';
    this.speed = aviation != null ? aviation.speed : '';
    this.horsePower = aviation != null ? aviation.horsePower : '';
    this.licensedPassengerSittingCapacity = aviation != null ? aviation.licensedPassengerSittingCapacity : '';
    this.currentLicense = aviation != null ? aviation.currentLicense : '';
    this.dateLicense = aviation != null ? aviation.dateLicense : '';
    this.identificationMark = aviation != null ? aviation.identificationMark : '';
    this.manufacturersName = aviation != null ? aviation.manufacturersName : '';
    this.registrationNumber = aviation != null ? aviation.registrationNumber : '';
    this.registrationPlace = aviation != null ? aviation.registrationPlace : '';
    this.excessDeductibles = aviation != null ? aviation.excessDeductibles : '';
    this.sumInsured = aviation != null ? aviation.sumInsured : '';
    this.premiumOrRate = aviation != null ? aviation.premiumOrRate : '';
    this.prorataDays = aviation != null ? aviation.prorataDays : '';
    this.proratePremium = aviation != null ? aviation.proratePremium : '';
    this.lastClaimDate = aviation != null ? aviation.lastClaimDate : '';
    this.policyNumber = aviation != null ? aviation.policyNumber : '';

    this.coInsurances = aviation != null ? aviation.coInsurances : [];
    this.extensionDiscounts = aviation != null ? aviation.extensionDiscounts : [];
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    voyageFroms: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'voyage from', 'parentId': null }, 'setUpValues', false),
    voyageTos: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'voyage to', 'parentId': null }, 'setUpValues', false),
    extensionTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Extension Types', 'parentId': null }, 'setUpValues', false),
    licenseTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'License Type', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Policy Type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'Insurance Companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    var aviationId = $('#hdAviation').val();
    var customerId = $('#hdCustomer').val();

    //infoViewModel.customer = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', { customerId: customerId }, 'customerData', false);

    //for a new Agent Registration
    if (aviationId == 0) {
        infoViewModel.info = new info(null);
    }

        //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Aviation/EditData/',
            contentType: "application/json",
            type: "GET",
            data: {aviationId: aviationId},
            success: function (data) {
                infoViewModel.info = data;
            }
        });
    }

    infoViewModel.info.customerId = customerId;

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal')
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal');
            }
        }
    })

    validate();
});

function validate() {
    $form = $('#aviation').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            insuredInterest: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            clauses: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            exclusion: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            yearOfManufacture: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            voyageFrom: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            voyageTo: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }

            },
            placeOfManufacture: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }

            },
            numbersOfCrew: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            priceOfAirCraft: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            pilotDetails: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            survey: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            insurancePurpose: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            fuel: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            speed: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            horsePower: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            sittingCapacity: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            dateLicense: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentLicensed: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            identificationMark: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            manufacturerName: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            registrationNumber: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            registrationPlace: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            excessDeductibles: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            premiumOrRate: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            prorataDays: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            proratePremium: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            extensionOfDiscount: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            lastClaimDate: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            riskProfile: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'Aviation/Create');
            submitFn.clearFields('aviation');
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.coInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.coInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            type: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentage: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.extensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.extensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}