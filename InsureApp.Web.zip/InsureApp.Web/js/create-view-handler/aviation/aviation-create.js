﻿function info(aviation) {
    this.id = aviation != null ? aviation.id : '';
    this.insuredInterest = aviation != null ? aviation.insuredInterest : '';
    this.voyageFrom = aviation != null ? aviation.voyageFrom : '';
    this.voyageTo = aviation != null ? aviation.voyageTo : '';
    this.clauses = aviation != null ? aviation.clauses : '';
    this.exclusions = aviation != null ? aviation.exclusions : '';
    this.yearOfManufacture = aviation != null ? aviation.yearOfManufacture : '';
    this.placeOfManufacture = aviation != null ? aviation.placeOfManufacture : '';
    this.numberOfCrew = aviation != null ? aviation.numberOfCrew : '';
    this.riskProfile = aviation != null ? aviation.riskProfile : '';
    this.priceOfAirCraft = aviation != null ? aviation.priceOfAirCraft : '';
    this.pilotDetails = aviation != null ? aviation.pilotDetails : '';
    this.totalDeclarationValueForInsurancePurpose = aviation != null ? aviation.totalDeclarationValueForInsurancePurpose : '';
    this.survey = aviation != null ? aviation.survey : '';
    this.fuel = aviation != null ? aviation.fuel : '';
    this.speed = aviation != null ? aviation.speed : '';
    this.horsePower = aviation != null ? aviation.horsePower : '';
    this.licensedPassengerSittingCapacity = aviation != null ? aviation.licensedPassengerSittingCapacity : '';
    this.currentLicense = aviation != null ? aviation.currentLicense : '';
    this.dateOfLicensed = aviation != null ? aviation.dateOfLicensed : '';
    this.identificationMark = aviation != null ? aviation.identificationMark : '';
    this.deductibles = aviation != null ? aviation.deductibles : '';
    this.manufacturersName = aviation != null ? aviation.manufacturersName : '';
    this.registrationNumber = aviation != null ? aviation.registrationNumber : '';
    this.registrationPlace = aviation != null ? aviation.registrationPlace : '';
    this.excessDeductibles = aviation != null ? aviation.excessDeductibles : '';
    this.sumInsured = aviation != null ? aviation.sumInsured : '';
    this.premiumOrRate = aviation != null ? aviation.premiumOrRate : '';
    this.prorataDays = aviation != null ? aviation.prorataDays : '';
    this.proratePremium = aviation != null ? aviation.proratePremium : '';
    this.lastClaimDate = aviation != null ? aviation.lastClaimDate : '';
    this.policyNumber = aviation != null ? aviation.policyNumber : '';

    this.aviationCoInsurances = aviation != null ? aviation.aviationCoInsurances : [];
    this.aviationExtensionDiscounts = aviation != null ? aviation.aviationExtensionDiscounts : [];
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    aviationCoInsurance: new coInsurance(null),
    aviationExtensionDiscount: new extensionDiscount(null),
    riskProfiles: new GetDataFromServer().loadData('/RiskProfile/GetRiskProfiles', { 'setUpName': 'premium risk', 'parentId': null }, 'riskProfiles', false),
    voyageFroms: new GetDataFromServer().loadData('/RiskProfile/GetSetUpValues', { 'setUpName': 'voyage from', 'parentId': null }, 'setUpValues', false),
    voyageTos: new GetDataFromServer().loadData('/RiskProfile/GetSetUpValues', { 'setUpName': 'voyage to', 'parentId': null }, 'setUpValues', false),
}

$(function () {
    var aviationId = $('#hdAviation').val();
    var custId = $('#hdCustomer').val();

    infoViewModel.customer = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', { custId: custId }, 'customerData', false);

    //for a new Agent Registration
    if (aviationId == 0) {
        infoViewModel.info = new info(null);
    }

        //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Aviation/EditData/' + aviationId,
            contentType: "application/json",
            type: "GET",
            success: function (data) {
                var stateDropDown = new GetDropDownData();
                stateDropDown.load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': data.nationality }, 'states', 'setUpValues', false);
                infoViewModel.info = data;
            }
        });
    }
    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.aviationCoInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal')
            },
            callModal2: function () {
                app.vm.aviationExtensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal');
            }
        }
    })

    validate();
});

function validate() {
    $form = $('#aviation').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            insuredInterest: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            clauses: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            exclusion: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            yearOfManufacture: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            voyageFrom: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            voyageTo: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }

            },
            placeOfManufacture: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }

            },
            numbersOfCrew: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            priceOfAirCraft: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            pilotDetails: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            survey: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            insurancePurpose: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            fuel: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            speed: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            horsePower: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            sittingCapacity: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            dateOfLicensed: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentLicensed: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            identificationMark: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            deductibles: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            manufacturerName: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            registrationNumber: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            registrationPlace: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            excessDeductible: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            premiumOrRate: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            prorataDays: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            proratePremium: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            extensionOfDiscount: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            lastClaimDate: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            riskProfile: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'Aviation/Create');
            submitFn.clearFields('aviation');
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.aviationCoInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.aviationCoInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            type: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentage: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.aviationExtensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.aviationExtensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}


function coInsuranceDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.aviationCoInsurances.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.aviationCoInsurances.splice(arrayIndex, 1);
        }
    });
}

function coInsuranceEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.aviationCoInsurances.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.aviationCoInsurance = value;
        }
    });
    $('#' + 'coInsuranceModal').modal();
}

function extensionDiscountDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.aviationExtensionDiscounts.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.aviationExtensionDiscounts.splice(arrayIndex, 1);
        }
    });
}

function extensionDiscountEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.aviationExtensionDiscounts.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.aviationExtensionDiscount = value;
        }
    });
    $('#' + 'extensionDiscountModal').modal();
}

function populateExtensionDiscounts(obj) {
    var aviationExtensionDiscount = JSON.parse(JSON.stringify(obj));

    if (aviationExtensionDiscountExist(aviationExtensionDiscount)) {
        return;
    }
    else if (aviationExtensionDiscount.id != '') {
        app.vm.info.aviationExtensionDiscounts.forEach(function (value, index) {
            if (aviationExtensionDiscount.id == value.id) {
                value = aviationExtensionDiscount;
            }
        });
    }
    else {
        aviationExtensionDiscount.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.aviationExtensionDiscounts.push(aviationExtensionDiscount);
    }
}

//checks to see if contact person already exist
function aviationExtensionDiscountExist(aviationExtensionDiscount) {
    var state = false;
    app.vm.info.aviationExtensionDiscounts.forEach(function (value, index) {
        if (aviationExtensionDiscount.id == ''
            && aviationExtensionDiscount.policyNumber.toLowerCase() == value.policyNumber.toLowerCase()
            && aviationExtensionDiscount.description.toLowerCase() == value.description.toLowerCase()) {
            state = true;
        }
    });
    return state;
}

//adds contact person to contactPerson Array after checking for duplicates or update request
function populateCoInsurance(obj) {
    var aviationCoInsurance = JSON.parse(JSON.stringify(obj));

    if (aviationCoInsuranceExist(aviationCoInsurance)) {
        return;
    }
    else if (aviationCoInsurance.id != '') {
        app.vm.info.aviationCoInsurances.forEach(function (value, index) {
            if (aviationCoInsurance.id == value.id) {
                value = aviationCoInsurance;
            }
        });
    }
    else {
        aviationCoInsurance.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.aviationCoInsurances.push(avitionCoInsurance);
    }
}

//checks to see if contact person already exist
function aviationCoInsuranceExist(aviationCoInsurance) {
    var state = false;
    app.vm.info.aviationCoInsurances.forEach(function (value, index) {
        if (avitionCoInsurance.id == ''
            && aviationCoInsurance.participant.toLowerCase() == value.participant.toLowerCase()) {
            state = true;
        }
    });
    return state;
}
