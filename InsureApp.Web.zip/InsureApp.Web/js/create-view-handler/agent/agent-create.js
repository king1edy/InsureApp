﻿function info(agent) {
    this.id = agent != null ? agent.id : '';
    this.name = agent != null ? agent.name : '';
    this.registrationNumber = agent != null ? agent.registrationNumber : '';
    this.dateOfRegistration = agent != null ? agent.dateOfRegistration : '';
    this.agentClass = agent != null ? agent.agentClass : '';
    this.agentType = agent != null ? agent.agentType : '';
    this.address = agent != null ? agent.address : '';
    this.country = agent != null ? agent.country : '';
    this.state = agent != null ? agent.state : '';
    this.phone = agent != null ? agent.phone : '';
    this.email = agent != null ? agent.email : '';
    this.website = agent != null ? agent.website : '';
    this.status = agent != null ? agent.status : '';
    this.transactionCurrency = agent != null ? agent.transactionCurrency : '';
    this.commisionClass = agent != null ? agent.commisionClass : '';
    this.aggregate = agent != null ? agent.aggregate : '';
    this.agentContacts = agent != null ? agent.agentContacts : [];
}

function agentContact(agentContact) {
    this.id = agentContact != null ? agentContact.id : '';
    this.agentId = agentContact != null ? agentContact.agentId : '';
    this.firstName = agentContact != null ? agentContact.firstName : '';
    this.lastName = agentContact != null ? agentContact.lastName : '';
    this.email = agentContact != null ? agentContact.email : '';
    this.phone = agentContact != null ? agentContact.phone : '';
    this.designation = agentContact != null ? agentContact.designation : '';
}


var infoViewModel = {
    info: new info(null),
    agentContact : new agentContact(null),
    countries: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'country', 'parentId': null }, 'setUpValues', false),
    agentClasses: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'agent class', 'parentId': null }, 'setUpValues', false),
    agentTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'agent type', 'parentId': null }, 'setUpValues', false),
    status: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'status', 'parentId': null }, 'setUpValues', false),
    transactionCurrencies: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'transaction currency', 'parentId': null }, 'setUpValues', false),
    commissionClasses: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'commission class', 'parentId': null }, 'setUpValues', false),
    states: []
}

$(function () {
    var agentId = $('#hdAgent').val();

    //for a new Agent Registration
    if (agentId == 0) {
        infoViewModel.info = new info(null);
    }

    //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Agent/EditData/' + agentId,
            contentType: "application/json",
            type: "GET",
            success: function (data) {
                var stateDropDown = new GetDropDownData();
                stateDropDown.load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': data.nationality }, 'states', 'setUpValues', false);
                infoViewModel.info = data;
            }
        });
    }
    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.agentContact = new agentContact(null);
                submitFn.callModal('myModal2')
            },
            loadStates: function () {
                var stateDropDown = new GetDropDownData();
                stateDropDown.load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': app.vm.info.country }, 'states', 'setUpValues', false);
            }
        }
    })

    validate();
});
/*
 * Bootstrap Form Validator 
 */
function validate() {
    //TODO: Validation of the main form
    $('#form').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: '<strong>Company Name</strong> Required'
                    }
                }
            },
            dateOfRegistration: {
                validators: {
                    notEmpty: {
                        message: '<strong>Registration Date</strong> Required'
                    }
                }
            },
            registrationNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Registration Number</strong> Required'
                    }
                }
            },
            agentClass:{
                validations: {
                    notEmpty: {
                        meassage: '<strong>Agency Class</strong> Required'
                    }
                }
            },
            agentType: {
                validations: {
                    notEmpty: {
                        meassage: '<strong>Agency Type</strong> Required'
                    }
                }
            },
            country: {
                validators: {
                    notEmpty: {
                        message: '<strong>Country</strong> Required'
                    }
                }
            },
            state: {
                validators: {
                    notEmpty: {
                        message: '<strong>State/Province</strong> Required'
                    }
                }
            },
            address: {
                validators: {
                    notEmpty: {
                        message: '<strong>Address</strong> Required'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: '<strong>Email</strong> Required'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: '<strong>Phone Number</strong> Required'
                    }
                }
            },
        website: {
            validators: {
                notEmpty: {
                    message: '<strong>Web Site</strong> Required'
                }
            }
        },
        status: {
            validators: {
                notEmpty: {
                    message: '<strong>Status</strong> Required'
                }
            }
        },
        transCurrency: {
            validators: {
                notEmpty: {
                    message: '<strong>Transaction Currency</strong> Required'
                }
            }
        },
        commissionClass: {
            validators: {
                notEmpty: {
                    message: '<strong>Commission Class</strong> Required'
                }
            }
        },
        aggregate: {
            validators: {
                notEmpty: {
                    message: '<strong>Aggregate</strong> Required'
                }
            }
        }
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'Agent/Create');
            submitFn.clearFields('form')
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for the sub-form
    $('#addContactForm').bootstrapValidator({
        client: '#sub-messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            agentId: {
                validators: {
                    notEmpty: {
                        message: '<strong>Agent Id</strong> Required'
                    }
                }
            },
            firstName: {
                validators: {
                    notEmpty: {
                        message: '<strong>First Name</strong> Required'
                    }
                }
            },
            lastName:{
                validations:{
                    notEmpty: {
                        message: '<strong>Last Name</strong> Required'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: '<strong>Email</strong> Required'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: '<strong>Phone Number</strong> Required'
                    }
                }
            },
            designation: {
                validations: {
                    notEmpty: {
                        message: '<strong>Designation</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateAgentContacts(app.vm.agentContact);
            submitFn.successAlert()
            $('#addContactForm').bootstrapValidator('resetForm', true);
            app.vm.agentContact = new agentContact(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

//sets up the contact person table display for delete operations using javascript's hooks
function contactDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.agentContacts.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.agentContacts.splice(arrayIndex, 1);
        }
    });
}

function contactEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.agentContacts.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.agentContact = value;
        }
    });
    $('#' + 'myModal2').modal();
}

//returns screen to the grid display of corporate customers
$('#btnBackToAgent').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', null);
    myAjaxCall();
});

//adds contact person to contactPerson Array after checking for duplicates or update request
function populateAgentContacts(obj) {
    var agentContact = JSON.parse(JSON.stringify(obj));
    
    if (agentContactExist(agentContact)) {
        return;
    }
    else if (agentContact.id != '') {
        app.vm.info.agentContacts.forEach(function (value, index) {
            if (agentContact.id == value.id) {
                value = agentContact;
            }
        });
    }
    else {
        agentContact.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.agentContacts.push(agentContact);

        //app.vm.agentContact = new agentContact(null);
    }
}

//checks to see if contact person already exist
function agentContactExist(agentContact) {
    var state = false;
    app.vm.info.agentContacts.forEach(function (value, index) {
        if (agentContact.id == ''
            && agentContact.firstName.toLowerCase() == value.firstName.toLowerCase()
            && agentContact.email.toLowerCase() == value.email.toLowerCase()
            && agentContact.phone == agentContact.phone) {
            state = true;
        }
    });
    return state;
}