﻿$('#loadForm').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', { customerId: 0 }, true);
})


function editRow(sender) {
    var url = $(sender).attr('data-UrlStructure');
    var urlStructure = url;
    var dataId = $(sender).attr('data-id');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', { customerId: dataId }, true);
    return false;
}
