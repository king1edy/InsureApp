﻿function info(corporate) {
    this.id = corporate != null ? corporate.id : '';
    this.companyName = corporate != null ? corporate.companyName : '';
    this.yearIncorporated = corporate != null ? corporate.yearIncorporated : '';
    this.nationality = corporate != null ? corporate.nationality : '';
    this.stateProvince = corporate != null ? corporate.stateProvince : '';
    this.streetName = corporate != null ? corporate.streetName : '';
    this.phone = corporate != null ? corporate.phone : '';
    this.email = corporate != null ? corporate.email : '';
    this.pmb = corporate != null ? corporate.pmb : '';
    this.website = corporate != null ? corporate.website : '';
    this.natureOfBusiness = corporate != null ? corporate.natureOfBusiness : '';
    this.registrationNumber = corporate != null ? corporate.registrationNumber : '';
    this.contactPersons = corporate != null ? corporate.contactPersons : [];
}

function contactPerson(contactPerson) {
    this.id = contactPerson != null ? contactPerson.id : '';
    this.firstName = contactPerson != null ? contactPerson.firstName : '';
    this.lastName = contactPerson != null ? contactPerson.lastName : '';
    this.email = contactPerson != null ? contactPerson.email : '';
    this.phone = contactPerson != null ? contactPerson.phone : '';
    this.designation = contactPerson != null ? contactPerson.designation : '';
    this.isBoardMember = contactPerson != null ? contactPerson.isBoardMember : '';
}

var infoViewModel = {
    info: new info(null),
    contactPerson : new contactPerson(null),
    countries: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'country', 'parentId': null }, 'setUpValues', false),
    states: []
}

$(function () {
    var customerId = $('#hdCustomer').val();

    //for a new Corporate Customer Registration
    if (customerId == 0) {
        infoViewModel.info = new info(null);
    }
    //for updating existing Customer Registration
    else {
        $.ajax({
            url: 'CorporateCustomer/EditData/' + customerId,
            contentType: "application/json",
            type: "GET",
            success: function (data) {
                var stateDropDown = new GetDropDownData();
                stateDropDown.load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': data.nationality }, 'states', 'setUpValues', false);
                infoViewModel.info = data;
            }
        });
    }
    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.contactPerson = new contactPerson(null);
                submitFn.callModal('myModal2')
            },
            loadStates: function () {
                var stateDropDown = new GetDropDownData();
                stateDropDown.load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': app.vm.info.nationality }, 'states', 'setUpValues');
            }
        }
    })

    validate();
});

/* Bootstrap Form Validator*/
function validate() {
    //TODO: Validation of the main form
    $('#form').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            companyName: {
                validators: {
                    notEmpty: {
                        message: '<strong>Company Name</strong> Required'
                    }
                }
            },
            yearIncorporated: {
                validators: {
                    notEmpty: {
                        message: '<strong>Year Incorporated</strong> Required'
                    }
                }
            },
            boardMember: {
                validators: {
                    notEmpty: {
                        message: '<strong>Board Member</strong> Required'
                    }
                }
            },
            nationality: {
                validators: {
                    notEmpty: {
                        message: '<strong>Nationality</strong> Required'
                    }
                }
            },
            state: {
                validators: {
                    notEmpty: {
                        message: '<strong>State/Province</strong> Required'
                    }
                }
            },
            streetName: {
                validators: {
                    notEmpty: {
                        message: '<strong>Street Number</strong> Required'
                    }
                }
            },
            buildingNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Building Number</strong> Required'
                    }
                }
            },
            pmb: {
                validators: {
                    notEmpty: {
                        message: '<strong>PO. Box/PMB</strong> Required'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: '<strong>Email</strong> Required'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: '<strong>Phone Number</strong> Required'
                    }
                }
            },
            designation: {
                validators: {
                    notEmpty: {
                        message: '<strong>Designation</strong> Required'
                    }
                }
            }
        },
        natureOfBusiness:{
            validators: {
                notEmpty: {
                    message: '<strong>Nature Of Business</strong> Required'
                }
            }
        },
        registrationNumber:{
            validators: {
                notEmpty: {
                    message: '<strong>Registration Number</strong> Required'
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'CorporateCustomer/Create');
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for the sub-form
    $('#addContactForm').bootstrapValidator({
        client: '#sub-messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            customer: {
                validators: {
                    notEmpty: {
                        message: '<strong>Title</strong> Required'
                    }
                }
            },
            firstName: {
                validators: {
                    notEmpty: {
                        message: '<strong>First Name</strong> Required'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: '<strong>Email</strong> Required'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: '<strong>Phone Number</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateContactPersons(app.vm.contactPerson);
            submitFn.successAlert()
            $('#addContactForm').bootstrapValidator('resetForm', true);
            app.vm.contactPerson = new contactPerson(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}

//returns screen to the grid display of corporate customers
$('#btnBackToCorporate').on('click', function (e) {
    e.preventDefault();
    var url = $(this).attr('href');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', null);
});

//adds contact person to contactPerson Array after checking for duplicates or update request
function populateContactPersons(obj) {
    var contactPerson = JSON.parse(JSON.stringify(obj));

    if(contactPersonExist(contactPerson)){
        return;
    }
    else if(contactPerson.id != ''){
        app.vm.info.contactPersons.forEach(function (value, index) {
            if (contactPerson.id == value.id) {
                value = contactPerson;
            }
        });
    }
    else {
        contactPerson.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.contactPersons.push(contactPerson);
    }
}

//checks to see if contact person already exist
function contactPersonExist(contactPerson){
    var state = false;
    app.vm.info.contactPersons.forEach(function (value, index) {
        if (contactPerson.id == ''
            && contactPerson.firstName.toLowerCase() == value.firstName.toLowerCase()
            && contactPerson.email.toLowerCase() == value.email.toLowerCase()
            && contactPerson.phone == contactPerson.phone) {
            state = true;
        }
    });
    return state;
}

//sets up the contact person table display for delete operations using javascript's hooks
function contactDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.contactPersons.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.contactPersons.splice(arrayIndex, 1);
        }
    });
}

function contactEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.contactPersons.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.contactPerson = value;
        }
    });
    $('#' + 'myModal2').modal();
}