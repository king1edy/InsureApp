﻿function info(marine) {
    this.id = marine != null ? marine.id : '';
    this.customerId = marine != null ? marine.customerId : '';
    this.customerNumber = marine != null ? marine.customerNumber : '';
    this.formMNumber =  marine != null ? marine.formMNumber : '';
    this.voyageFrom =  marine != null ? marine.voyageFrom : '';
    this.voyageTo =  marine != null ? marine.voyageTo : '';
    this.insuredInterest =  marine != null ? marine.insuredInterest : '';
    this.invoiceValue =  marine != null ? marine.invoiceValue : '';
    this.conditions =  marine != null ? marine.conditions : '';
    this.packageType = marine != null ? marine.packageType : '';
    this.bankInterest = marine != null ? marine.bankInterest : '';
    this.exclusiveType = marine != null ? marine.exclusiveType : '';
    this.vesselName = marine != null ? marine.vesselName : '';
    this.clientAddress = marine != null ? marine.clientAddress : '';
    this.proformalInvoiceNumber = marine != null ? marine.proformalInvoiceNumber : '';
    this.inspectionDate = marine != null ? marine.inspectionDate : '';
    this.itemNumber = marine != null ? marine.itemNumber : '';
    this.effectiveDate = marine != null ? marine.effectiveDate : '';
    this.excess = marine != null ? marine.excess : '';
    this.sumInsured =  marine != null ? marine.sumInsured : '';
    this.premiumOrRate = marine != null ? marine.premiumOrRate : '';
    this.marineType = marine != null ? marine.marineType : 'MarineCargo';

    //hull properties
    this.yearOfManufacture = marine != null ? marine.yearOfManufacture : '';
    this.placeOfManufacture = marine != null ? marine.placeOfManufacture : '';
    this.deductibles = marine != null ? marine.deductibles : '';
    this.manufacturersNumber = marine != null ? marine.manufacturersNumber : '';
    this.registrationNumber =  marine != null ? marine.registrationNumber : '';
    this.registrationPlace = marine != null ? marine.registrationPlace : '';
    this.tonnage = marine != null ? marine.tonnage : '';
    this.engineType = marine != null ? marine.engineType : '';
    this.dimensionLength = marine != null ? marine.dimensionLength : '';
    this.priceOfHull = marine != null ? marine.priceOfHull : '';
    this.dateOfPurchase = marine != null ? marine.dateOfPurchase : '';
    this.currentHullValue = marine != null ? marine.currentHullValue : '';
    this.sailingHours = marine != null ? marine.sailingHours : '';
    this.declarationValue = marine != null ? marine.declarationValue : '';
    this.survey = marine != null ? marine.survey : '';
    this.fuel = marine != null ? marine.fuel : '';
    this.speed = marine != null ? marine.speed : '';
    this.horsePower = marine != null ? marine.horsePower : '';
    this.lastClaimDate = marine != null ? marine.lastClaimDate : '';
    this.ageOfVessel = marine != null ? marine.ageOfVessel : '';
    this.nameOfCapital = marine != null ? marine.nameOfCapital : '';
    this.riskProfile = marine != null ? marine.riskProfile : '';

    this.coInsurances = marine != null ? marine.coInsurances : [];
    this.extensionDiscounts = marine != null ? marine.extensionDiscounts : [];
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    voyageFroms: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'voyage from', 'parentId': null }, 'setUpValues', false),
    voyageTos: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'voyage to', 'parentId': null }, 'setUpValues', false),
    engineTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', {'setUpName': 'engine type'}, 'setUpValues', false),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    extensionTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'extension types', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'policy type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'insurance companies', 'parentId': null }, 'setUpValues', false)
}

$(function () {
    var customerId = $('#hdCustomer').val();
    var marineId = $('#hdMarine').val();

    //infoViewModel.customer = new GetDataFromServer().loadData('CustomerSearch/ConfirmData/', { custId: custId }, 'customerData', false);

    //for a new Agent Registration
    if (marineId == 0) {
        infoViewModel.info = new info(null);
    }

        //for updating existing Agent Registration
    else {
        $.ajax({
            url: 'Marine/EditData/',
            contentType: "application/json",
            type: "GET",
            data: { id: marineId },
            success: function (data) {
                infoViewModel.info = data;
                console.log(JSON.parse(JSON.stringify(data)).marineType);
            }
        });
    }

    infoViewModel.info.customerId = customerId;

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            formVisibility: true,
            marineHull: false
        },
        updated: function (){
            this.marineHull = this.vm.info.marineType == "MarineCargo" ? false : true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal');
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal');
            }
            //callModal: function () {
            //    submitFn.callModal('myModal2')
            //}
        }
    })

    validate();
});

/*
 * Bootstrap Form Validator 
 */
function validate() {
    //TODO: Validation of the main form
    $('#marineForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            formMNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            vesselName: {
                validators: {
                    notEmpty: {
                        message: '<strong>Vessel Name</strong> Required'
                    }
                }
            },
            voyageFrom: {
                validators: {
                    notEmpty: {
                        message: '<strong>Voyage From</strong> Required'
                    }
                }
            },
            voyageTo: {
                validators: {
                    notEmpty: {
                        message: '<strong>Voyage To</strong> Required'
                    }
                }
            },
            insuredInterest: {
                validators: {
                    notEmpty: {
                        message: '<strong>Insured Interest</strong> Required'
                    }
                }
            },
            invoiceValue: {
                validators: {
                    notEmpty: {
                        message: '<strong>Invoice Value</strong> Required'
                    }
                }

            },
            conditions: {
                validators: {
                    notEmpty: {
                        message: '<strong>Conditions</strong> Required'
                    }
                }
            },
            invoiceValue: {
                validators: {
                    notEmpty: {
                        message: '<strong>Invoice Value</strong> Required'
                    }
                }
            },
            bankInterest: {
                validators: {
                    notEmpty: {
                        message: '<strong>Bank Interest</strong> Required'
                    }
                }
            },
            packageType: {
                validators: {
                    notEmpty: {
                        message: '<strong>Package Type</strong> Required'
                    }
                }
            },
            proformalInvoiceNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Proformal Invoice Number</strong> Required'
                    }
                }
            },
            effectiveDate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Effective Date</strong> Required'
                    }
                }
            },
            excess: {
                validators: {
                    notEmpty: {
                        message: '<strong>Excess</strong> Required'
                    }
                }
            },
            inspectionDate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Inspection Date</strong> Required'
                    }
                }
            },
            itemNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Item Number</strong> Required'
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                        message: '<strong>Sum Insured</strong> Required'
                    }
                }
            },
            premiumOrRate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Premium Or Rate</strong> Required'
                    }
                }
            },
            excess: {
                validators: {
                    notEmpty: {
                        message: '<strong>Excess</strong> Required'
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                        message: '<strong>Sum Insured</strong> Required'
                    }
                }
            },
            premiumOrRate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Premium Or Rate</strong> Required'
                    }
                }
            },
            clientAddress: {
                validators: {
                    notEmpty: {
                        message: '<strong>Client Address</strong> Required'
                    }
                }
            },
            yearOfManufacture: {
                validators: {
                    notEmpty: {
                        message: '<strong>Year Of Manufacture</strong> Required'
                    }
                }
            },
            placeOfManufacture: {
                validators: {
                    notEmpty: {
                        message: '<strong>Place Of Manufacture</strong> Required'
                    }
                }
            },
            deductibles: {
                validators: {
                    notEmpty: {
                        message: '<strong>Deductibles</strong> Required'
                    }
                }
            },
            
            manufacturersNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Manufacturers Name</strong> Required'
                    }
                }
            },
            registrationNumber: {
                validators: {
                    notEmpty: {
                        message: '<strong>Registration Number</strong> Required'
                    }
                }
            },
            registrationPlace: {
                validators: {
                    notEmpty: {
                        message: '<strong>Registration Place</strong> Required'
                    }
                }
            },
            tonnage: {
                validators: {
                    notEmpty: {
                        message: '<strong>Tonnage</strong> Required'
                    }
                }
            },
            engineType: {
                validators: {
                    notEmpty: {
                        message: '<strong>Engine Type</strong> Required'
                    }
                }
            },
            dimensionLength: {
                validators: {
                    notEmpty: {
                        message: '<strong>Dimension Length</strong> Required'
                    }
                }
            },
            priceOfHull: {
                validators: {
                    notEmpty: {
                        message: '<strong>Price of Hull</strong> Required'
                    }
                }
            },
            currentHullValue: {
                validators: {
                    notEmpty: {
                        message: '<strong>Current Hull Value </strong> Required'
                    }
                }
            },
            sailingHours: {
                validators: {
                    notEmpty: {
                        message: '<strong>Sailing Hours</strong> Required'
                    }
                }
            },
            insurancePurpose: {
                validators: {
                    notEmpty: {
                        message: '<strong>Insurance Purpose</strong> Required'
                    }
                }
            },
            ageOfVessel: {
                validators: {
                    notEmpty: {
                        message: '<strong>Age of Vessel</strong> Required'
                    }
                }
            },
            nameOfCapital: {
                validators: {
                    notEmpty: {
                        message: '<strong>Name of Capital</strong> Required'
                    }
                }
            },
            dateOfPurchase: {
                validators: {
                    notEmpty: {
                        message: '<strong>Date of Purchase</strong> Required'
                    }
                }
            },
            placeOfManufacture: {
                validators: {
                    notEmpty: {
                        message: '<strong>Place of Manufacture</strong> Required'
                    }
                }
            },
            survey: {
                validators: {
                    notEmpty: {
                        message: '<strong>Survey</strong> Required'
                    }
                }
            },
            fuel: {
                validators: {
                    notEmpty: {
                        message: '<strong>Fuel</strong> Required'
                    }
                }
            },
            speed: {
                validators: {
                    notEmpty: {
                        message: '<strong>Speed</strong> Required'
                    }
                }
            },
            horsePower: {
                validators: {
                    notEmpty: {
                        message: '<strong>Horse Power</strong> Required'
                    }
                }
            },
            lastClaimDate: {
                validators: {
                    notEmpty: {
                        message: '<strong>Last Claim Date</strong> Required'
                    }
                }
            },
            declarationValue: {
                validators: {
                    notEmpty: {
                        message: '<strong>Last Claim Date</strong> Required'
                    }
                }
            },
            riskProfile: {
                // The group will be set as default (.form-group)
                validators: {
                    notEmpty: {
                        message: '<strong>Risk Profile</strong> Required'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            //check if Insert is for Cargo
            if (!app.marineHull) {
                submitFn.saveData(new info(null), 'Marine/CreateCargo');
            }
            else {
                submitFn.saveData(new info(null), 'Marine/CreateHull');
            }
            submitFn.clearFields('marineForm');
        },
        onError: function (e) {
            e.preventDefault();
        }
    })


    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.coInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.coInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            type: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentage: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.extensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.extensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}