﻿function info(fire) {
    this.id = fire != null ? fire.id : '';
    this.customerId = fire != null ? fire.customerId : '';
    this.businessType = fire != null ? fire.businessType : '';
    this.insuredInterest = fire != null ? fire.insuredInterest : '';
    this.businessOccupation = fire != null ? fire.businessOccupation : '';
    this.riskProfile = fire != null ? fire.riskProfile : '';
    this.maximumProbableLoss = fire != null ? fire.maximumProbableLoss : '';
    this.situationOfRisk = fire != null ? fire.situationOfRisk : '';
    this.itemNumber = fire != null ? fire.itemNumber : '';
    this.additionalInsured = fire != null ? fire.additionalInsured : '';
    this.excess = fire != null ? fire.excess : '';
    this.sumInsured = fire != null ? fire.sumInsured : '';
    this.premiumOrRate = fire != null ? fire.premiumOrRate : '';
    this.prorataDays = fire != null ? fire.prorataDays : '';
    this.proratePremium = fire != null ? fire.proratePremium : '';
    this.lastClaimDate = fire != null ? fire.lastClaimDate : '';
    this.policyNumber = fire != null ? fire.policyNumber : '';
    this.type = fire != null ? fire.type : '';

    this.coInsurances = fire != null ? fire.coInsurances : [];
    this.extensionDiscounts = fire != null ? fire.extensionDiscounts : [];
}

var infoViewModel = {
    info: new info(null),
    customer: new customer(null),
    coInsurance: new coInsurance(null),
    extensionDiscount: new extensionDiscount(null),
    businessTypes: new GetDataFromServer().loadData('/MiscSetUpValue/GetSetUpValues', {'setUpName': 'business type', 'parentId': null},'setUpValues', false),
    businessOccupations: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'business occupation', 'parentId': null }, 'setUpValues', false),
    riskProfiles: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'risk profile', 'parentId': null }, 'setUpValues', false),
    extensionTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'extension types', 'parentId': null }, 'setUpValues', false),
    policyTypes: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'policy type', 'parentId': null }, 'setUpValues', false),
    participants: new GetDataFromServer().loadData('/MiscSetupValue/GetSetUpValues', { 'setUpName': 'insurance companies', 'parentId': null }, 'setUpValues', false)
}


$(function () {
    var fireId = $('#hdFire').val();
    var customerId = $('#hdCustomer').val();


    //for a new Fire Registration
    if (fireId == 0) {
        infoViewModel.info = new info(null);
    }

    //for updating existing Fire Registration
    else {
        $.ajax({
            url: 'Fire/EditData/' + fireId,
            contentType: "application/json",
            type: "GET",
            success: function (data) {
                var stateDropDown = new GetDropDownData();
                stateDropDown.load('/MiscSetupValue/GetSetUpValues', app.vm, { 'setUpName': 'state', 'parentId': data.nationality }, 'states', 'setUpValues', false);
                infoViewModel.info = data;
            }
        });
    }

    infoViewModel.info.customerId = customerId;

    app = new Vue({
        el: "#create-form",
        data: {
            loading: false,
            vm: infoViewModel,
            loading: false,
            formVisibility: true
        },
        methods: {
            callModal: function () {
                app.vm.coInsurance = new coInsurance(null);
                submitFn.callModal('coInsuranceModal');
            },
            callModal2: function () {
                app.vm.extensionDiscount = new extensionDiscount(null);
                submitFn.callModal('extensionDiscountModal');
            }
        }
    })

    validate();
});

//Bootstrap Validatoion
function validate() {
    $form = $('#fire').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            insuredInterest: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            effectiveDate: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            probableLoss: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    },
                    stringLength: {
                        max: 80,
                        message: 'Probable loss name must be less than 80 characters long'
                    }
                }
            },
            risk: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    },
                    stringLength: {
                        max: 20,
                        message: 'Risk field must be less than 20 characters long'
                    }
                }
            },
            businessType: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            businessOccupation: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }

            },
            itemNumber: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            date: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            additionalInsured: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            excess: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            premiumOrRate: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            prorataDays: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            proratePremium: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            lastClaimDate: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyNumber: {
                group: '.col-md-4',
                validators: {
                    notEmpty: {
                    }
                }
            },
            riskProfile: {
                // The group will be set as default (.form-group)
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            submitFn.saveData(new info(null), 'Fire/Create');
            submitFn.clearFields('fire');
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Co-Insurance sub-form
    $('#coInsuranceForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            participant: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            sumInsured: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isPrincipal: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            premium: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentageShare: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateCoInsurance(app.vm.coInsurance);
            submitFn.successAlert();
            $("#coInsuranceForm").bootstrapValidator('resetForm', true);
            app.vm.coInsurance = new coInsurance(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })

    //TODO: Validation for Extension Discount sub-form

    $('#extensionDiscountForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            policyNumber: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            description: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            type: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            percentage: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            applyTo: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            isExcluded: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            amount: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            currentNet: {
                validators: {
                    notEmpty: {
                    }
                }
            },
            policyType: {
                validators: {
                    notEmpty: {
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            populateExtensionDiscounts(app.vm.extensionDiscount);
            submitFn.successAlert();
            $("#extensionDiscountForm").bootstrapValidator('resetForm', true);
            app.vm.extensionDiscount = new extensionDiscount(null);
        },
        onError: function (e) {
            e.preventDefault();
        }
    })
}
// end fire form