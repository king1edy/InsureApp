﻿//loads search page for subscription
$('#loadSearchForm').on('click', function (e) {
    e.preventDefault();
    var policyType = $(e.target).attr('data-policy-type');
    var url = $(e.target).attr('href');
    var data = { formType: 'single', policyType: policyType };
    loadSearch(url, data);
})

$('ul li a#loadSearchForm').on('click', function (e) {
    e.preventDefault();
    var policyType = $(e.target).attr('data-policy-type');
    var url = $(e.target).attr('href');
    var data = { formType: 'multiple', policyType: policyType };
    loadSearch(url, data);
})

function loadSearch(url, data) {
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', data, true);
}

function editRow(sender) {
    var customerId = $(sender).attr('data-customer-id');
    var url = $(sender).attr('data-UrlStructure');
    var dataId = $(sender).attr('data-id');
    var call = new MyAjaxCall();
    call.load(url, 'div#mainDisplay', { fireId: dataId, customerId: customerId });
}