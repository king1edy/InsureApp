﻿
function coInsuranceDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.coInsurances.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.coInsurances.splice(arrayIndex, 1);
        }
    });
}

function coInsuranceEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.coInsurances.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.coInsurance = value;
        }
    });
    $('#' + 'coInsuranceModal').modal();
}

function extensionDiscountDelete(obj) {
    var id = $(obj).attr('data-row-id');
    $(obj).confirmation({
        onConfirm: function () {
            var id = $(obj).attr('data-row-id');
            var arrayIndex = null;
            app.vm.info.extensionDiscounts.forEach(function (value, index) {
                if (id == value.id) {
                    arrayIndex = index;
                }
            })
            app.vm.info.extensionDiscounts.splice(arrayIndex, 1);
        }
    });
}

function extensionDiscountEdit(obj) {
    var id = $(obj).attr('data-row-id');
    app.vm.info.extensionDiscounts.forEach(function (value, index) {
        if (id == value.id) {
            app.vm.extensionDiscount = value;
        }
    });
    $('#' + 'extensionDiscountModal').modal();
}

function populateExtensionDiscounts(obj) {
    var extensionDiscount = JSON.parse(JSON.stringify(obj));

    if (extensionDiscountExist(extensionDiscount)) {
        return;
    }
    else if (extensionDiscount.id != '') {
        app.vm.info.extensionDiscounts.forEach(function (value, index) {
            if (extensionDiscount.id == value.id) {
                value = extensionDiscount;
            }
        });
    }
    else {
        extensionDiscount.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.extensionDiscounts.push(extensionDiscount);
    }
}

//checks to see if contact person already exist
function extensionDiscountExist(extensionDiscount) {
    var state = false;
    app.vm.info.extensionDiscounts.forEach(function (value, index) {
        if (extensionDiscount.id == ''
            && extensionDiscount.policyNumber.toLowerCase() == value.policyNumber.toLowerCase()
            && extensionDiscount.description.toLowerCase() == value.description.toLowerCase()) {
            state = true;
        }
    });
    return state;
}

//adds contact person to contactPerson Array after checking for duplicates or update request
function populateCoInsurance(obj) {
    var coInsurance = JSON.parse(JSON.stringify(obj));

    if (coInsuranceExist(coInsurance)) {
        return;
    }
    else if (coInsurance.id != '') {
        app.vm.info.coInsurances.forEach(function (value, index) {
            if (coInsurance.id == value.id) {
                value = coInsurance;
            }
        });
    }
    else {
        coInsurance.id = Math.floor(1000 + Math.random() * 9000);
        app.vm.info.coInsurances.push(coInsurance);
    }
}

//checks to see if contact person already exist
function coInsuranceExist(coInsurance) {
    var state = false;
    app.vm.info.coInsurances.forEach(function (value, index) {
        if (coInsurance.id == ''
            && coInsurance.participant.toLowerCase() == value.participant.toLowerCase()) {
            state = true;
        }
    });
    return state;
}
