var submitFn = (function() {
    function successAlert() {
        $.smallBox({
            title: "Success",
            content: "Data Submitted",
            color: "#27e362",
            timeout: 4000,
            icon: "fa fa-check"
        });
    }

    function errorAlert(title, content) {
        $.smallBox({
            title: title,
            content: content,
            color: "#ff0039",
            timeout: 4000,
            icon: "fa fa-exclamation-triangle"
        });
    }

    function clearFields(formId) {
        $form = $("#" + formId);
        $form.bootstrapValidator('resetForm', true);
    }


    function saveData(model, url) {
        
        $.ajax({
            url: url,
            async: false,
            contentType: "application/json",
            data: JSON.stringify(app.vm.info),
            type: "POST",
            beforeSend: function () {
                $('#ajax-spinner').show();
            },
            success: function (data) {
                if (data.success) {
                    successAlert();
                    submitFn.clearFields('form');
                    app.vm.info = model;
                }
                else if(!data.success){
                    errorAlert("Error", data.reason);   
                }
            },
            complete: function(){
                $('#ajax-spinner').hide();
                $('#form').find('button.btn.btn-success').removeAttr('disabled');
            },
            error: function (jqXHR, textStatus, errorThrown) {
                errorAlert("Error", "jqXHR: " + jqXHR + "textStatus :" + textStatus + "errorThrown: " + errorThrown);
            }
        });
        app.info = model;
    }

    function addContactPerson() {
        //app.vm.info.contactPersons.push(app.vm.contactPerson);
        //app.vm.contactPerson = new contactPerson(null)
        clearFields('addContactForm')
        successAlert()
    }

    function callModal(modalName) {
        $('#' + modalName).modal()
    }
    return {
        saveData: saveData,
        addContactPerson: addContactPerson,
        callModal: callModal,
        clearFields: clearFields,
        successAlert: successAlert
    }
})();