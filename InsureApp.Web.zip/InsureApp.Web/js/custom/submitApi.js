var submitFn = (function() {
    function successAlert() {
        $.smallBox({
            title: "Success",
            content: "Data Submitted",
            color: "#27e362",
            timeout: 4000,
            icon: "fa fa-check"
        });
    }

    function errorAlert(title, content) {
        $.smallBox({
            title: title,
            content: content,
            color: "#ff0039",
            timeout: 4000,
            icon: "fa fa-exclamation-triangle"
        });
    }

    function clearFields(formId) {
        $form = $("#" + formId);
        $form.bootstrapValidator('resetForm', true);
    }


    function saveData(model, url) {
       
        $.ajax({
            url: url,
            async: true,
            contentType: "application/json",
            data: JSON.stringify(app.vm.info),
            type: "POST",
            beforeSend: function () {
                app.loading = true;
            },
            success: function (data) {
                app.loading = false;
                if (data.success) {
                    successAlert();
                    submitFn.clearFields('form');
                    app.vm.info = model;
                }
                else if(!data.success){
                    errorAlert("Error", data.reason);   
                }
            },
            complete: function(){
                app.loading = false;
                $('#form').find('button.btn.btn-success').removeAttr('disabled');
            },
            error: function (jqXHR, textStatus, errorThrown) {
                errorAlert("Error", "jqXHR: " + jqXHR + "textStatus :" + textStatus + "errorThrown: " + errorThrown);
            }
        });
        app.info = model;
    }

    function saveDataMultiple(url, batchItems, fileInput) {

       $.ajax({
            url: url,
            async: true,
            contentType: "application/json",
            data: JSON.stringify(app.vm.info),
            type: "POST",
            beforeSend: function () {
                app.loading = true;
            },
            success: function (data) {
                app.loading = false;
                if (data.success) {
                    successAlert();
                
                    // Draw once all updates are done
                    myDataTable.destroy();
                    $('#' + batchItems).empty();
                    $('#' + fileInput).val('');

                    app.submitBtn = false;

                    app.vm.info.coInsurances = [];
                    app.vm.info.extensionDiscounts = [];
                }
                else if (!data.success) {
                    errorAlert("Error", data.reason);
                }
            },
            complete: function () {
                app.loading = false;
                $('#form').find('button.btn.btn-success').removeAttr('disabled');
            },
            error: function (jqXHR, textStatus, errorThrown) {
                errorAlert("Error", "jqXHR: " + jqXHR + "textStatus :" + textStatus + "errorThrown: " + errorThrown);
            }
        });
    }

    function addContactPerson() {
        //app.vm.info.contactPersons.push(app.vm.contactPerson);
        //app.vm.contactPerson = new contactPerson(null)
        clearFields('addContactForm')
        successAlert()
    }

    function callModal(modalName) {
        $('#' + modalName).modal()
    }
    return {
        saveData: saveData,
        saveDataMultiple: saveDataMultiple,
        addContactPerson: addContactPerson,
        callModal: callModal,
        clearFields: clearFields,
        successAlert: successAlert
    }
})();