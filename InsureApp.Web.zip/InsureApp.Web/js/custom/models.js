function dropDownData(id, name) {
    this.id = id;
    this.name = name;
}

function coInsurance(coInsurance) {
    this.id = coInsurance != null ? coInsurance.id : '';
    this.premium = coInsurance != null ? coInsurance.premium : '';
    this.policyNumber = coInsurance != null ? coInsurance.policyNumber : '';
    this.policyType = coInsurance != null ? coInsurance.policyType : '';
    this.isPrincipal = coInsurance != null ? coInsurance.isPrincipal : '';
    this.participant = coInsurance != null ? coInsurance.participant : '';
    this.sumInsured = coInsurance != null ? coInsurance.sumInsured : '';
    this.percentageShare = coInsurance != null ? coInsurance.percentageShare : '';
}

function extensionDiscount(extensionDiscount) {
    this.id = extensionDiscount != null ? extensionDiscount.id : '';
    this.policyNumber = extensionDiscount != null ? extensionDiscount.policyNumber : '';
    this.policyType = extensionDiscount != null ? extensionDiscount.policyType : '';
    this.description = extensionDiscount != null ? extensionDiscount.description : '';
    this.amount = extensionDiscount != null ? extensionDiscount.amount : '';
    this.type = extensionDiscount != null ? extensionDiscount.type : '';
    this.applyTo = extensionDiscount != null ? extensionDiscount.applyTo : '';
    this.isExclued = extensionDiscount != null ? extensionDiscount.isExclued : '';
    this.currentNet = extensionDiscount != null ? extensionDiscount.currentNet : '';
}

function customer(obj) {
    this.firstName = obj != null ? obj.firstName : "";
    this.lastName = obj != null ? obj.lastName : "";
    this.email = obj != null ? obj.email : "";
    this.phone = obj != null ? obj.phone : "";
    this.dob = obj != null ? obj.dob : "";
    this.gender = obj != null ? obj.gender : "";

    this.companyName = obj != null ? obj.companyName : '';
    this.yearIncorporated = obj != null ? obj.yearIncorporated : '';
    this.website = obj != null ? obj.website : '';
    this.natureOfBusiness = obj != null ? obj.natureOfBusiness : '';
    this.registrationNumber = obj != null ? obj.registrationNumber : '';
}