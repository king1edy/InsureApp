﻿function MyAjaxCall() {

    this.load = function (url, displayGrid, data, isAsync) {
        $.ajax({
            url: url,
            async: isAsync,
            dataType: "html",
            data: data,
            beforeSend: function () {
                $(displayGrid).empty();
                $(displayGrid).html('<img id="loader-img" alt="" src="img/ajax_loader2.gif" width="100" height="100" style="position: absolute; right: 46%; top: 35vh;" />');
            },
            success: function (data) {
                $(displayGrid).html(data);
                MVCGrid.init();
            }
        });
    }
}

function GetDropDownData() {

    this.load = function (url, viewModel, dataToSend, viewModelArrayProperty, returnData, isAsync) {
        $.ajax({
            async: isAsync,
            url: url,
            contentType: "application/json",
            type: "GET",
            data: dataToSend,
            success: function (data) {
                var parentData = data[returnData];
                if (parentData) {
                    viewModel[viewModelArrayProperty] = [];
                    parentData.forEach(function (value) {
                        viewModel[viewModelArrayProperty].push(new dropDownData(value.id, value.name));
                    });
                }
            }
        });
    }
}

function GetDataFromServer() {

    this.loadData = function (url, dataToSend, returnData, isAsync) {
        var result = [];
        $.ajax({
            async: isAsync,
            url: url,
            contentType: "application/json",
            type: "GET",
            data: dataToSend,
            success: function (data) {
                var parentData = data[returnData];
                if (parentData) {
                    result = parentData
                }
            }
        });
        return result;
    }
}
