﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using System.Threading;

namespace InsureApp.Web.Controllers
{
    public class TravelAndHealthController : Controller
    {
        ITravelAndHealthService service;
        IMapper mapper;

        
        public TravelAndHealthController(ITravelAndHealthService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /OrgStructureName/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /TravelAndHealth Add
        public ActionResult Create(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(TravelAndHealthDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                   .SelectMany(E => E.Errors)
                   .Select(E => E.ErrorMessage)
                   .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<TravelAndHealth>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(int TravelAndHealthId)
        {
            ViewBag.TravelAndHealthId = TravelAndHealthId;
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            TravelAndHealth obj = service.GetById(Id);
            var result = mapper.Map<TravelAndHealthDto>(obj);
            result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
            result.TravellingDate = Convert.ToDateTime(result.TravellingDate).ToString("MM/dd/yyyy");
            result.ReturningDate = Convert.ToDateTime(result.ReturningDate).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<TravelAndHealthDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            TravelAndHealth obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        public ActionResult Delete(int Id, TravelAndHealthDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        public ActionResult CreateMultiple(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        public ActionResult Validate(TravelAndHealthDto obj)
        {
            Thread.Sleep(500);
            int ran = new Random().Next(0, 27);
            bool status = ran % 2 == 0 ? true : false;
            obj.Status = status.ToString();
            return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = new { data = obj } };
        }
	}
}