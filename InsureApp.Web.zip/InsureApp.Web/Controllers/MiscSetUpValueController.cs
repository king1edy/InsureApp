﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsureApp.Infrastructure;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using AutoMapper;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class MiscSetUpValueController : Controller
    {
        IMiscSetUpValueService service;
        IMiscSetUpNameService setupNameService;
        IMapper mapper;

        public MiscSetUpValueController(IMiscSetUpValueService service, IMapper mapper, IMiscSetUpNameService setupNameService)
        {
            this.service = service;
            this.setupNameService = setupNameService;
            this.mapper = mapper;
        }
        //
        // GET: /MiscSetUpValue/
        public ActionResult Index(MiscSetUpValueParam param)
        {
            ViewBag.NameId = Convert.ToInt32(param.NameId);
            ViewBag.ParentId = param.ParentId.Contains("NaN") ? 0 : Convert.ToInt32(param.ParentId);
            return PartialView();
        }

        public ActionResult Create()
        {
            return PartialView();
        }

        public ActionResult Edit()
        {
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            MiscSetUpValue obj = service.GetByID(Id);
            var result = mapper.Map<MiscSetUpValueDto>(obj);
            return new JsonCamelCaseResult(new { setUpValue = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Create(MiscSetUpValueDto dto)
        {
            string message = string.Empty;

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation  Failed." });
            }

            var obj = mapper.Map<MiscSetUpValue>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Get()
        {
            var allSetUpValues = service.GetAll().ToList();
            var listSetUpValues = mapper.Map<List<MiscSetUpValueDto>>(allSetUpValues);

            var allSetupNames = setupNameService.GetAll().ToList();
            var listSetUpNames = mapper.Map<List<MiscSetUpNameDto>>(allSetupNames);

            return new JsonCamelCaseResult(new { setUpValues = listSetUpValues, setUpNames = listSetUpNames }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetParent(int ParentId)
        {
            var allSetUpValues = service.GetAll().Where(m => m.SetUpNameId == ParentId).ToList();
            var listSetUpValues = mapper.Map<List<MiscSetUpValueDto>>(allSetUpValues);

            return new JsonCamelCaseResult(new { parentData = listSetUpValues }, JsonRequestBehavior.AllowGet);
        }
        
        public ActionResult GetSetupValues(SetUpNameValueParam param)
        {
            List<MiscSetUpValue> allSetUpValues = null;
            List<MiscSetUpValueDto> listSetUpValues = null;

            if (param.ParentId == null)
            {            
                allSetUpValues = service.GetAll().Where(m => m.MiscSetUpName.Name.ToLower() == param.SetUpName.ToLower()).ToList();
                listSetUpValues = mapper.Map<List<MiscSetUpValueDto>>(allSetUpValues);
            }
            else
            {
                allSetUpValues = service.GetAll().Where(m => m.MiscSetUpName.Name.ToLower() == param.SetUpName.ToLower() && m.MiscSetUpValue2.Name == param.ParentId).ToList();
                listSetUpValues = mapper.Map<List<MiscSetUpValueDto>>(allSetUpValues);
            }
            return new JsonCamelCaseResult(new { setUpValues = listSetUpValues}, JsonRequestBehavior.AllowGet);
        }
	}
}