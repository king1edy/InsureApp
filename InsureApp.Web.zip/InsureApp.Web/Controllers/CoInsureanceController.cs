﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InsureApp.Web.Controllers
{
    public class CoInsureanceController : Controller
    {
        //
        // GET: /CoInsureance/
        public ActionResult Index()
        {
            return View();
        }
	}
}