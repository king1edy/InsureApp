﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;

namespace InsureApp.Web.Controllers
{
    public class CustomerSearchController : Controller
    {
        ICustomerService service;
        IMapper mapper;

        public CustomerSearchController(ICustomerService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // Get: Motor Search
        public ActionResult Search(string formType, string policyType)
        {
            ViewBag.formType = formType;
            ViewBag.policyType = policyType;
            return PartialView();
        }

        // Get: Motor Search
        public ActionResult FireSearch()
        {
            return PartialView();
        }

        // Get: Motor Search
        public ActionResult AviationSearch()
        {
            return PartialView();
        }

        public ActionResult Confirm(long CustId)
        {
            ViewBag.CustId = CustId;
            return PartialView(); 
        }

        public ActionResult ConfirmData(long CustId)
        {
            Customer obj = service.GetAll().Where(m => m.CustId == CustId).FirstOrDefault();

            if (obj.CustomerType == "Private")
            {
                var customer = mapper.Map<PrivateCustomerDto>(obj);
                customer.DOB = Convert.ToDateTime(customer.DOB).ToString("MM/dd/yyyy");
                return new JsonCamelCaseResult(new { customerData = customer }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var customer = mapper.Map<CorporateCustomerDto>(obj);
                customer.YearIncorporated = Convert.ToDateTime(customer.YearIncorporated).ToString("MM/dd/yyyy");
                return new JsonCamelCaseResult(new { customerData = customer }, JsonRequestBehavior.AllowGet);
            }
        }

   }
}