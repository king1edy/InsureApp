﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;

namespace InsureApp.Web.Controllers
{
    public class AgentController : Controller
    {
        IAgentService service;
        IMapper mapper;

        public AgentController(IAgentService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /Aviation/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /Aviation Add
        public ActionResult Create(int AgentId)
        {
            ViewBag.AgentId = AgentId;
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(AgentDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Agent>(dto);

            if (service.Save(obj, new List<AgentContact>(), ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(int AgentId)
        {
            ViewBag.AgentId = AgentId;
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            Agent obj = service.GetById(Id);
            var result = mapper.Map<AgentDto>(obj);
            result.DateOfRegistration = Convert.ToDateTime(result.DateOfRegistration).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<AgentDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Agent obj = service.GetById(Id);
            return PartialView();
        }

        public ActionResult Delete(int Id, AgentDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }
    }
}