﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class RiskProfileController : Controller
    {
        IRiskProfileService service;
        IMapper mapper;

        
        public RiskProfileController(IRiskProfileService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /OrgStructureName/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /OrgStructureName Add
        public ActionResult Create()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(RiskProfileDto dto)
        {
            string message = string.Empty;

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed." });
            }

            var obj = mapper.Map<RiskProfile>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit()
        {
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            RiskProfile obj = service.GetById(Id);
            var result = mapper.Map<RiskProfileDto>(obj);
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<RiskProfileDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetRiskProfiles(SetUpNameValueParam param)
        {
            List<RiskProfile> allRiskProfile = null;
            List<RiskProfileDto> listRiskProfile = null;

            if (param.ParentId == null)
            {
                allRiskProfile = service.GetAll().Where(m => m.Name.ToLower() == param.SetUpName.ToLower()).ToList();
                listRiskProfile = mapper.Map<List<RiskProfileDto>>(allRiskProfile);
            }
            else
            {
                allRiskProfile = service.GetAll().Where(m => m.Name.ToLower() == param.SetUpName.ToLower() && m.Id.ToString() == param.ParentId).ToList();
                listRiskProfile = mapper.Map<List<RiskProfileDto>>(allRiskProfile);
            }
            return new JsonCamelCaseResult(new { riskProfiles = listRiskProfile }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            RiskProfile obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        public ActionResult Delete(int Id, RiskProfileDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }
	}
}