﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using System.Threading;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class MotorController : Controller
    {
        IMotorService service;
        IMapper mapper;
        ICustomerService customerService;
        IMotorBatchService motorBatchService;

        public MotorController(IMotorService service, IMapper mapper, ICustomerService customerService, IMotorBatchService motorBatchService)
        {
            this.service = service;
            this.mapper = mapper;
            this.customerService = customerService;
            this.motorBatchService = motorBatchService;
        }

        // GET: /Motor/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: Motor Search
        public ActionResult Search()
        {
            return PartialView();
        }

        // Get: /Motor Add
        public ActionResult Create(long CustId)
        {
            ViewBag.CustId = CustId;
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto CustomerDto = helper.GetCustomerDetails(CustId, customerService, mapper, 0);
            return PartialView("Create", CustomerDto);
        }

        [HttpPost]
        public ActionResult Create(MotorDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Motor>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(long MotorId, long CustomerId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto customerDto = helper.GetCustomerDetails(CustomerId, customerService, mapper, MotorId);
            return PartialView("Create", customerDto);
        }

        public ActionResult EditData(int MotorId)
        {
            Motor obj = service.GetById(MotorId);
            var result = mapper.Map<MotorDto>(obj);
            result.CoverPeriodFrom = Convert.ToDateTime(result.CoverPeriodFrom).ToString("MM/dd/yyyy");
            result.InspectionDate = Convert.ToDateTime(result.InspectionDate).ToString("MM/dd/yyyy");
            result.EffectiveDate = Convert.ToDateTime(result.EffectiveDate).ToString("MM/dd/yyyy");
            result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<MotorDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Motor obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int Id, MotorDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        [HttpGet]
        public ActionResult CreateMultiple(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        [HttpPost]
        public ActionResult CreateMultiple(MotorBatchDto Dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            Random RndNum = new Random();

            Dto.NoOfRecords = Dto.Motors.Count();
            Dto.Reference = "MT" + RndNum.Next(10000000, 99999999).ToString();
            Dto.UploadDate = DateTime.Now;
            Dto.UploadBy = "";
            Dto.Status = "Pending";

            var obj = mapper.Map<MotorBatch>(Dto);

            if (motorBatchService.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Validate(MotorBatchDto obj)
        {
            Thread.Sleep(500);
            int ran = new Random().Next(0, 27);
            bool status = ran % 2 == 0 ? true : false;
            obj.Status = status.ToString();
            return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = new { data = obj } };
        }
	}
}