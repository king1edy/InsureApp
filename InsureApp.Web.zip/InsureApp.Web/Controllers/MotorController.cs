﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using System.Threading;

namespace InsureApp.Web.Controllers
{
    public class MotorController : Controller
    {
        IMotorService service;
        IMapper mapper;

        public MotorController(IMotorService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /Motor/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: Motor Search
        public ActionResult Search()
        {
            return PartialView();
        }

        // Get: /Motor Add
        public ActionResult Create(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(MotorDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Motor>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(int MotorId)
        {
            ViewBag.MotorId = MotorId;
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            Motor obj = service.GetById(Id);
            var result = mapper.Map<MotorDto>(obj);
            result.CoverPeriodFrom = Convert.ToDateTime(result.CoverPeriodFrom).ToString("MM/dd/yyyy");
            result.InspectionDate = Convert.ToDateTime(result.InspectionDate).ToString("MM/dd/yyyy");
            result.EffectiveDate = Convert.ToDateTime(result.EffectiveDate).ToString("MM/dd/yyyy");
            result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<MotorDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Motor obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int Id, MotorDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        public ActionResult CreateMultiple(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        public ActionResult Validate(MotorDto obj)
        {
            Thread.Sleep(500);
            int ran = new Random().Next(0, 27);
            bool status = ran % 2 == 0 ? true : false;
            obj.Status = status.ToString();
            return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = new { data = obj } };
        }
	}
}