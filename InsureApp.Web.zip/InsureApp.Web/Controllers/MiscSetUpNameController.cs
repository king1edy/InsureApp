﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsureApp.Infrastructure;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using AutoMapper;

namespace InsureApp.Web.Controllers
{
    public class MiscSetUpNameController : Controller
    {
        IMiscSetUpNameService service;
        IMapper mapper;

        public MiscSetUpNameController(IMiscSetUpNameService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }
        //
        // GET: /MiscSetUpName/
        public ActionResult Index()
        {
            return PartialView();
        }


        public ActionResult Create()
        {
            return PartialView();
        }

        public ActionResult Edit()
        {
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            MiscSetUpName obj = service.GetByID(Id);
            var result = mapper.Map<MiscSetUpNameDto>(obj);
            return new JsonCamelCaseResult(new { setUpName = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Create(MiscSetUpNameDto dto)
        {
            string message = string.Empty;

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation  Failed." });
            }

            var obj = mapper.Map<MiscSetUpName>(dto);

            if(service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<MiscSetUpNameDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }
	}
}