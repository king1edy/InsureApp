﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using System.Threading;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class TravelController : Controller
    {
        ITravelService service;
        IMapper mapper;
        ICustomerService customerService;

        
        public TravelController(ITravelService service, IMapper mapper, ICustomerService customerService)
        {
            this.service = service;
            this.mapper = mapper;
            this.customerService = customerService;
        }

        // GET: /OrgStructureName/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /TravelAndHealth Add
        public ActionResult Create(long CustId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto CustomerDto = helper.GetCustomerDetails(Convert.ToInt64(CustId), customerService, mapper, 0);
            return PartialView("Create", CustomerDto);
        }

        [HttpPost]
        public ActionResult Create(TravelDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                   .SelectMany(E => E.Errors)
                   .Select(E => E.ErrorMessage)
                   .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Travel>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(long TravelId, long CustomerId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto customerDto = helper.GetCustomerDetails(CustomerId, customerService, mapper, TravelId);
            return PartialView("Create", customerDto);
        }

        public ActionResult EditData(long Id)
        {
            Travel obj = service.GetById(Id);
            var result = mapper.Map<TravelDto>(obj);
            result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
            result.TravellingDate = Convert.ToDateTime(result.TravellingDate).ToString("MM/dd/yyyy");
            result.ReturningDate = Convert.ToDateTime(result.ReturningDate).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<TravelDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Travel obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        public ActionResult Delete(int Id, TravelDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        public ActionResult CreateMultiple(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        public ActionResult Validate(TravelDto obj)
        {
            Thread.Sleep(500);
            int ran = new Random().Next(0, 27);
            bool status = ran % 2 == 0 ? true : false;
            obj.Status = status.ToString();
            return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = new { data = obj } };
        }
	}
}