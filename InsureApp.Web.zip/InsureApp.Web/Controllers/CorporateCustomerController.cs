﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;

namespace InsureApp.Web.Controllers
{
    public class CorporateCustomerController : Controller
    {
        ICustomerService service;
        IMapper mapper;

        public CorporateCustomerController(ICustomerService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /Customer/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /Customer Add
        public ActionResult Create(int CustomerId)
        {
            ViewBag.CustomerId = CustomerId;
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(CorporateCustomerDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Customer>(dto);
            //var contactPersons = mapper.Map<List<ContactPerson>>(dto.ContactPersons);
            //obj.ContactPersons = new List<ContactPerson>();

            if (service.Save(obj, new List<ContactPerson>(), ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(int CustomerId)
        {
            ViewBag.CustomerId = CustomerId;
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            Customer obj = service.GetById(Id);
            var result = mapper.Map<CorporateCustomerDto>(obj);
            result.YearIncorporated = Convert.ToDateTime(result.YearIncorporated).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<CorporateCustomerDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Customer obj = service.GetById(Id);
            return PartialView();
        }

        public ActionResult Delete(int Id, CorporateCustomerDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }
	}
}