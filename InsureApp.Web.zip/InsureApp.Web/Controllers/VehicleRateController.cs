﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InsureApp.Web.Controllers
{
    public class VehicleRateController : Controller
    {
        //
        // GET: /VehicleRate/
        public ActionResult Index()
        {
            return PartialView();
        }
	}
}