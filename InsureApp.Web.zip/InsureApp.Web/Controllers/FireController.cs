﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using System.Threading;

namespace InsureApp.Web.Controllers
{
    public class FireController : Controller
    {
        IFireService service;
        IMapper mapper;

        
        public FireController(IFireService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /OrgStructureName/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /OrgStructureName Add
        public ActionResult Create(string custId)
        {
            ViewBag.custId = custId;
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(FireDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Fire>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(int FireId)
        {
            ViewBag.FireId = FireId;
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            Fire obj = service.GetById(Id);
            var result = mapper.Map<FireDto>(obj);
            result.EffectiveDate = Convert.ToDateTime(result.EffectiveDate).ToString("MM/dd/yyyy");
            result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<FireDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Fire obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        public ActionResult Delete(int Id, FireDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        public ActionResult CreateMultiple(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        public ActionResult Validate(FireDto obj)
        {
            Thread.Sleep(500);
            int ran = new Random().Next(0, 27);
            bool status = ran % 2 == 0 ? true : false;
            obj.Status = status.ToString();
            return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = new { data = obj } };
        }
	}
}