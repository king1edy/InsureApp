﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class MarineController : Controller
    {
        IMarineService service;
        IMapper mapper;
        ICustomerService customerService;


        public MarineController(IMarineService service, IMapper mapper, ICustomerService customerService)
        {
            this.service = service;
            this.mapper = mapper;
            this.customerService = customerService;
        }

        // GET: /OrgStructureName/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /OrgStructureName Add
        public ActionResult Create(long CustId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto CustomerDto = helper.GetCustomerDetails(Convert.ToInt64(CustId), customerService, mapper, 0);
            return PartialView("Create", CustomerDto);
        }

        [HttpPost]
        public ActionResult CreateCargo(MarineCargoDto dto)
        {
            string message = string.Empty;


            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Marine>(dto);
            obj.MarineType = "MarineCargo";

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        [HttpPost]
        public ActionResult CreateHull(MarineHullDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Marine>(dto);
            obj.MarineType = "MarineHull";

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(long MarineId, long CustomerId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto customerDto = helper.GetCustomerDetails(CustomerId, customerService, mapper, MarineId);
            return PartialView("Create", customerDto);
        }

        public ActionResult EditData(int Id)
        {
            Marine obj = service.GetById(Id);
            if (obj.MarineType.Equals("MarineCargo"))
            {
                var result = mapper.Map<MarineCargoDto>(obj);
                result.EffectiveDate = Convert.ToDateTime(result.EffectiveDate).ToString("MM/dd/yyyy");
                result.InspectionDate = Convert.ToDateTime(result.InspectionDate).ToString("MM/dd/yyyy");
                return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
            }
            else if (obj.MarineType.Equals("MarineHull"))
            {
                var result = mapper.Map<MarineHullDto>(obj);
                result.DateOfPurchase = Convert.ToDateTime(result.DateOfPurchase).ToString("MM/dd/yyyy");
                result.DischargeDate = Convert.ToDateTime(result.DischargeDate).ToString("MM/dd/yyyy");
                result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
                return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
            }
            return null;
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<MarineCargoDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Marine obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        public ActionResult Delete(int Id, MarineCargoDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        protected override void OnException(ExceptionContext filterContext)
        {
            Exception ex = filterContext.Exception;
            filterContext.ExceptionHandled = true;

            var model = new HandleErrorInfo(filterContext.Exception, "Controller", "Action");

            filterContext.Result = new ViewResult()
            {
                ViewName = "Error",
                ViewData = new ViewDataDictionary(model)
            };

        }
	}
}