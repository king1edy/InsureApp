﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;

namespace InsureApp.Web.Controllers
{
    public class GeneralAccidentController : Controller
    {
        IGeneralAccidentService service;
        IMapper mapper;

        
        public GeneralAccidentController(IGeneralAccidentService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /OrgStructureName/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /OrgStructureName Add
        public ActionResult Create()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(GeneralAccidentDto dto)
        {
            string message = string.Empty;

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed." });
            }

            var obj = mapper.Map<GeneralAccident>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit()
        {
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            GeneralAccident obj = service.GetById(Id);
            var result = mapper.Map<GeneralAccidentDto>(obj);
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<GeneralAccidentDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            GeneralAccident obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        public ActionResult Delete(int Id, GeneralAccidentDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }
	}
}