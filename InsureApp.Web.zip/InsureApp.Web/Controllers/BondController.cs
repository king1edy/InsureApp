﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class BondController : Controller
    {
        IBondService service;
        IMapper mapper;
        ICustomerService customerService;

        public BondController(IBondService service, IMapper mapper, ICustomerService customerService)
        {
            this.service = service;
            this.mapper = mapper;
            this.customerService = customerService;
        }

        // GET: /Bond/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /Bond Add
        public ActionResult Create(long CustId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto CustomerDto = helper.GetCustomerDetails(Convert.ToInt64(CustId), customerService, mapper, 0);
            return PartialView("Create", CustomerDto);
        }

        [HttpPost]
        public ActionResult Create(BondDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Bond>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(long BondId, long CustomerId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto customerDto = helper.GetCustomerDetails(CustomerId, customerService, mapper, BondId);
            return PartialView("Create", customerDto);
        }

        public ActionResult EditData(int Id)
        {
            Bond obj = service.GetById(Id);
            var result = mapper.Map<BondDto>(obj);
            result.EffectiveDate = Convert.ToDateTime(result.EffectiveDate).ToString("MM/dd/yyyy");
            result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
            result.InspectionDate = Convert.ToDateTime(result.InspectionDate).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<BondDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Bond obj = service.GetById(Id);
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int Id, BondDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }
	}
}