﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;

namespace InsureApp.Web.Controllers
{
    public class AgentContactController : Controller
    {
        IAgentContactService service;
        IMapper mapper;

        public AgentContactController(IAgentContactService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /Aviation/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /Aviation Add
        public ActionResult Create()
        {
            return PartialView();
        }
        [HttpPost]
        public ActionResult Create(AgentContactDto dto)
        {
            string message = string.Empty;

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed." });
            }

            var obj = mapper.Map<AgentContact>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit()
        {
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            AgentContact obj = service.GetById(Id);
            var result = mapper.Map<AgentContactDto>(obj);
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<AgentContactDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            AgentContact obj = service.GetById(Id);
            return PartialView();
        }

        public ActionResult Delete(int Id, AgentContactDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }
    }
}