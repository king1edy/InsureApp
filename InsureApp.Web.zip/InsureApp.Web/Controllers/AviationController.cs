﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using System.Threading;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class AviationController : Controller
    {
        IAviationService service;
        IMapper mapper;
        ICustomerService customerService;

        public AviationController(IAviationService service, IMapper mapper, ICustomerService customerService)
        {
            this.service = service;
            this.mapper = mapper;
            this.customerService = customerService;
        }

        // GET: /Aviation/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /Aviation Add
        public ActionResult Create(long custId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            return helper.GetCustomerDetails(custId, customerService, mapper, 0);
        }

        [HttpPost]
        public ActionResult Create(AviationDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. /n" + validationErrors });
            }

            var obj = mapper.Map<Aviation>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(long AviationId, long CustomerId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            return helper.GetCustomerDetails(CustomerId, customerService, mapper, AviationId);
        }

        public ActionResult EditData(long AviationId)
        {
            Aviation obj = service.GetById(AviationId);
            var result = mapper.Map<AviationDto>(obj);
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<AviationDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Aviation obj = service.GetById(Id);
            return PartialView();
        }

        public ActionResult Delete(int Id, AviationDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        public ActionResult CreateMultiple(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        public ActionResult Validate(AviationDto obj)
        {
            Thread.Sleep(500);
            int ran = new Random().Next(0, 27);
            bool status = ran % 2 == 0 ? true : false;
            obj.Status = status.ToString();
            return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = new { data = obj } };
        }

        
    }
}