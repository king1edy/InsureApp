﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InsureApp.Web.Controllers
{
    public class GasAndOilController : Controller
    {
        //
        // GET: /GasAndOil/
        public ActionResult Index()
        {
            return PartialView();
        }
	}
}