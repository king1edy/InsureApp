﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InsureApp.Infrastructure;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using AutoMapper;
using InsureApp.Web.Models;
using System.Threading;

namespace InsureApp.Web.Controllers
{
    public class GasAndOilController : Controller
    {
         IGasAndOilService service;
         IMapper mapper;
         ICustomerService customerService;

        public GasAndOilController(IGasAndOilService service, IMapper mapper, ICustomerService customerService)
        {
            this.service = service;
            this.mapper = mapper;
            this.customerService = customerService;
        }
        //
        // GET: /GasAndOil/
        public ActionResult Index()
        {
            return PartialView();
        }
        public ActionResult Create(long CustId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto CustomerDto = helper.GetCustomerDetails(Convert.ToInt64(CustId), customerService, mapper, 0);
            return PartialView("Create", CustomerDto);
        }

        [HttpPost]
        public ActionResult Create(GasAndOilDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation  Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<GasAndOil>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit(long OilAndGasId, long CustomerId)
        {
            SubscriptionHelper helper = new SubscriptionHelper();
            CustomerDto customerDto = helper.GetCustomerDetails(CustomerId, customerService, mapper, OilAndGasId);
            return PartialView("Create", customerDto);
        }

        public ActionResult EditData(int Id)
        {
            GasAndOil obj = service.GetByID(Id);
            var result = mapper.Map<GasAndOilDto>(obj);
            result.InspectionDate = Convert.ToDateTime(result.InspectionDate).ToString("MM/dd/yyyy");
            result.LastClaimDate = Convert.ToDateTime(result.LastClaimDate).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<GasAndOilDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            GasAndOil obj = service.GetByID(Id);
            return PartialView();
        }

        [HttpPost]
        public ActionResult Delete(int Id, GasAndOilDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        public ActionResult CreateMultiple(string custId)
        {
            ViewBag.CustId = custId;
            return PartialView();
        }

        public ActionResult Validate(GasAndOilDto obj)
        {
            Thread.Sleep(500);
            int ran = new Random().Next(0, 27);
            bool status = ran % 2 == 0 ? true : false;
            obj.Status = status.ToString();
            return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = new { data = obj } };
        }
    }
}