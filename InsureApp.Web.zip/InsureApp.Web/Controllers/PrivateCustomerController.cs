﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;

namespace InsureApp.Web.Controllers
{
    public class PrivateCustomerController : Controller
    {
        ICustomerService service;
        IMapper mapper;

        public PrivateCustomerController(ICustomerService service, IMapper mapper)
        {
            this.service = service;
            this.mapper = mapper;
        }

        // GET: /Customer/
        public ActionResult Index()
        {
            return PartialView();
        }

        // Get: /Customer Add
        public ActionResult Create()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(PrivateCustomerDto dto)
        {
            string message = string.Empty;

            string validationErrors = string.Join(",", ModelState.Values.Where(E => E.Errors.Count > 0)
                    .SelectMany(E => E.Errors)
                    .Select(E => E.ErrorMessage)
                    .ToArray());

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed. \n" + validationErrors });
            }

            var obj = mapper.Map<Customer>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit()
        {
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            Customer obj = service.GetById(Id);
            var result = mapper.Map<PrivateCustomerDto>(obj);
            result.DOB = Convert.ToDateTime(result.DOB).ToString("MM/dd/yyyy");
            return new JsonCamelCaseResult(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var all = service.GetAll().ToList();
            var list = mapper.Map<List<PrivateCustomerDto>>(all);
            return new JsonCamelCaseResult(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            Customer obj = service.GetById(Id);
            return PartialView();
        }

        public ActionResult Delete(int Id, PrivateCustomerDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }
	}
}