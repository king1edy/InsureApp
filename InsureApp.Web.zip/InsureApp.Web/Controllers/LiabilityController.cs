﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InsureApp.Web.Controllers
{
    public class LiabilityController : Controller
    {
        //
        // GET: /Liability/
        public ActionResult Index()
        {
            return PartialView();
        }
	}
}