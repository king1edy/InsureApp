﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using System.Web;
using System.Web.Mvc;
using InsureApp.Service.Abstract;
using InsureApp.ViewModel;
using InsureApp.Data;
using InsureApp.Infrastructure;
using AutoMapper;
using InsureApp.Web.Models;

namespace InsureApp.Web.Controllers
{
    public class OrgStructureValueController : Controller
    {
        IOrgStructureNameService orgStructureNameService;
        IOrgStructureValueService service;
        IMapper mapper;

        public OrgStructureValueController(IOrgStructureValueService service, IOrgStructureNameService orgStructureNameService, IMapper mapper)
        {
            this.service = service;
            this.orgStructureNameService = orgStructureNameService;
            this.mapper = mapper;
        }

        // GET: /OrgStructureValue/
        public ActionResult Index(OrgStructureValueParam param)
        {
            //Provide OrgStructureNameId to Use to filter Grid for OrgStructure Value Grid
            ViewBag.NameId = Convert.ToInt32(param.NameId);
            ViewBag.ParentId = param.ParentId.Contains("NaN") ? 0 : Convert.ToInt32(param.ParentId);
            return PartialView();
        }

        // Get: /OrgStructureValue Add
        public ActionResult Create()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult Create(OrgStructureValueDto dto)
        {
            string message = string.Empty;

            if (!ModelState.IsValid)
            {
                return Json(new { success = false, reason = "Validation Failed." });
            }

            var obj = mapper.Map<OrgStructureValue>(dto);

            if (service.Save(obj, ref message))
            {
                return Json(new { success = true, reason = string.Empty });
            }
            else
            {
                return Json(new { success = false, reason = message });
            }
        }

        public ActionResult Edit()
        {
            return PartialView("Create");
        }

        public ActionResult EditData(int Id)
        {
            OrgStructureValue obj = service.GetById(Id);
            var result = mapper.Map<OrgStructureValueDto>(obj);
            return new JsonCamelCaseResult(new { structureValue = result }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Get()
        {
            var allOrgStructureValue = service.GetAll().ToList();
            var listOrgStructureValue = mapper.Map<List<OrgStructureValueDto>>(allOrgStructureValue);

            var allOrgStructureName = orgStructureNameService.GetAll().ToList();
            var listOrgStructureName = mapper.Map<List<OrgStructureNameDto>>(allOrgStructureName);
            return new JsonCamelCaseResult(new { structureNames = listOrgStructureName, structureValues = listOrgStructureValue }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int Id)
        {
            OrgStructureValue obj = service.GetById(Id);
            return PartialView();
        }

        public ActionResult Delete(int Id, OrgStructureValueDto obj)
        {
            service.Remove(Convert.ToInt32(obj.Id));
            return View();
        }

        public ActionResult GetParent(int ParentId)
        {
            List<OrgStructureValue> obj = service.GetAll().Where(m => m.OrgStructureNameId == ParentId).ToList();
            var result = mapper.Map<List<OrgStructureValueDto>>(obj);
            return new JsonCamelCaseResult(new { parentData = result }, JsonRequestBehavior.AllowGet);
        }
	}
}